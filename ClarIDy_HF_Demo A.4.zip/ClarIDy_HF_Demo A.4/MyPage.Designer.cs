﻿namespace ClarIDy_HF_DEMO
{
    partial class MyPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MyPage));
            this.lblCoin = new System.Windows.Forms.Label();
            this.lblNickname = new System.Windows.Forms.Label();
            this.lblUserID = new System.Windows.Forms.Label();
            this.lblTime = new System.Windows.Forms.Label();
            this.lblCard = new System.Windows.Forms.Label();
            this.lblTimeU = new System.Windows.Forms.Label();
            this.lblCoinU = new System.Windows.Forms.Label();
            this.lblNickameU = new System.Windows.Forms.Label();
            this.lblUserIdU = new System.Windows.Forms.Label();
            this.lblCardU = new System.Windows.Forms.Label();
            this.btnIntro = new System.Windows.Forms.Button();
            this.btnLogout = new System.Windows.Forms.Button();
            this.pictUser = new System.Windows.Forms.PictureBox();
            this.btnEnter = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictUser)).BeginInit();
            this.SuspendLayout();
            // 
            // lblCoin
            // 
            this.lblCoin.AutoSize = true;
            this.lblCoin.BackColor = System.Drawing.Color.Transparent;
            this.lblCoin.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblCoin.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lblCoin.Location = new System.Drawing.Point(259, 316);
            this.lblCoin.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCoin.Name = "lblCoin";
            this.lblCoin.Size = new System.Drawing.Size(58, 21);
            this.lblCoin.TabIndex = 15;
            this.lblCoin.Text = "金幣：";
            // 
            // lblNickname
            // 
            this.lblNickname.AutoSize = true;
            this.lblNickname.BackColor = System.Drawing.Color.Transparent;
            this.lblNickname.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblNickname.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lblNickname.Location = new System.Drawing.Point(259, 208);
            this.lblNickname.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNickname.Name = "lblNickname";
            this.lblNickname.Size = new System.Drawing.Size(58, 21);
            this.lblNickname.TabIndex = 14;
            this.lblNickname.Text = "名稱：";
            // 
            // lblUserID
            // 
            this.lblUserID.AutoSize = true;
            this.lblUserID.BackColor = System.Drawing.Color.Transparent;
            this.lblUserID.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblUserID.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lblUserID.Location = new System.Drawing.Point(259, 244);
            this.lblUserID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblUserID.Name = "lblUserID";
            this.lblUserID.Size = new System.Drawing.Size(90, 21);
            this.lblUserID.TabIndex = 12;
            this.lblUserID.Text = "電子郵件：";
            // 
            // lblTime
            // 
            this.lblTime.AutoSize = true;
            this.lblTime.BackColor = System.Drawing.Color.Transparent;
            this.lblTime.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblTime.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lblTime.Location = new System.Drawing.Point(259, 352);
            this.lblTime.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTime.Name = "lblTime";
            this.lblTime.Size = new System.Drawing.Size(90, 21);
            this.lblTime.TabIndex = 16;
            this.lblTime.Text = "遊歷時間：";
            // 
            // lblCard
            // 
            this.lblCard.AutoSize = true;
            this.lblCard.BackColor = System.Drawing.Color.Transparent;
            this.lblCard.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblCard.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lblCard.Location = new System.Drawing.Point(259, 280);
            this.lblCard.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCard.Name = "lblCard";
            this.lblCard.Size = new System.Drawing.Size(58, 21);
            this.lblCard.TabIndex = 17;
            this.lblCard.Text = "卡號：";
            // 
            // lblTimeU
            // 
            this.lblTimeU.AutoSize = true;
            this.lblTimeU.BackColor = System.Drawing.Color.Transparent;
            this.lblTimeU.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblTimeU.Location = new System.Drawing.Point(370, 352);
            this.lblTimeU.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTimeU.Name = "lblTimeU";
            this.lblTimeU.Size = new System.Drawing.Size(105, 20);
            this.lblTimeU.TabIndex = 22;
            this.lblTimeU.Text = "尚未開始遊歷";
            // 
            // lblCoinU
            // 
            this.lblCoinU.AutoSize = true;
            this.lblCoinU.BackColor = System.Drawing.Color.Transparent;
            this.lblCoinU.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblCoinU.Location = new System.Drawing.Point(370, 316);
            this.lblCoinU.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCoinU.Name = "lblCoinU";
            this.lblCoinU.Size = new System.Drawing.Size(105, 20);
            this.lblCoinU.TabIndex = 21;
            this.lblCoinU.Text = "尚無金幣紀錄";
            // 
            // lblNickameU
            // 
            this.lblNickameU.AutoSize = true;
            this.lblNickameU.BackColor = System.Drawing.Color.Transparent;
            this.lblNickameU.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblNickameU.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lblNickameU.Location = new System.Drawing.Point(370, 208);
            this.lblNickameU.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNickameU.Name = "lblNickameU";
            this.lblNickameU.Size = new System.Drawing.Size(41, 20);
            this.lblNickameU.TabIndex = 20;
            this.lblNickameU.Text = "名稱";
            this.lblNickameU.Click += new System.EventHandler(this.lblNickameU_Click);
            // 
            // lblUserIdU
            // 
            this.lblUserIdU.AutoSize = true;
            this.lblUserIdU.BackColor = System.Drawing.Color.Transparent;
            this.lblUserIdU.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblUserIdU.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lblUserIdU.Location = new System.Drawing.Point(370, 244);
            this.lblUserIdU.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblUserIdU.Name = "lblUserIdU";
            this.lblUserIdU.Size = new System.Drawing.Size(73, 20);
            this.lblUserIdU.TabIndex = 18;
            this.lblUserIdU.Text = "電子郵件";
            // 
            // lblCardU
            // 
            this.lblCardU.AutoSize = true;
            this.lblCardU.BackColor = System.Drawing.Color.Transparent;
            this.lblCardU.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblCardU.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lblCardU.Location = new System.Drawing.Point(370, 280);
            this.lblCardU.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCardU.Name = "lblCardU";
            this.lblCardU.Size = new System.Drawing.Size(41, 20);
            this.lblCardU.TabIndex = 23;
            this.lblCardU.Text = "卡號";
            // 
            // btnIntro
            // 
            this.btnIntro.BackColor = System.Drawing.Color.Tan;
            this.btnIntro.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnIntro.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnIntro.Location = new System.Drawing.Point(133, 449);
            this.btnIntro.Margin = new System.Windows.Forms.Padding(4);
            this.btnIntro.Name = "btnIntro";
            this.btnIntro.Size = new System.Drawing.Size(267, 44);
            this.btnIntro.TabIndex = 25;
            this.btnIntro.Text = "遊戲介紹";
            this.btnIntro.UseVisualStyleBackColor = false;
            this.btnIntro.Click += new System.EventHandler(this.btnIntro_Click);
            // 
            // btnLogout
            // 
            this.btnLogout.BackColor = System.Drawing.Color.Tan;
            this.btnLogout.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnLogout.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnLogout.Location = new System.Drawing.Point(408, 449);
            this.btnLogout.Margin = new System.Windows.Forms.Padding(4);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(115, 44);
            this.btnLogout.TabIndex = 24;
            this.btnLogout.Text = "登出";
            this.btnLogout.UseVisualStyleBackColor = false;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // pictUser
            // 
            this.pictUser.BackColor = System.Drawing.Color.Transparent;
            this.pictUser.Location = new System.Drawing.Point(47, 201);
            this.pictUser.Margin = new System.Windows.Forms.Padding(4);
            this.pictUser.Name = "pictUser";
            this.pictUser.Size = new System.Drawing.Size(180, 194);
            this.pictUser.TabIndex = 26;
            this.pictUser.TabStop = false;
            this.pictUser.Click += new System.EventHandler(this.pictUser_Click);
            // 
            // btnEnter
            // 
            this.btnEnter.BackColor = System.Drawing.Color.Tan;
            this.btnEnter.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnEnter.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnEnter.Location = new System.Drawing.Point(408, 397);
            this.btnEnter.Margin = new System.Windows.Forms.Padding(4);
            this.btnEnter.Name = "btnEnter";
            this.btnEnter.Size = new System.Drawing.Size(115, 44);
            this.btnEnter.TabIndex = 27;
            this.btnEnter.Text = "進入遊戲";
            this.btnEnter.UseVisualStyleBackColor = false;
            this.btnEnter.Click += new System.EventHandler(this.btnEnter_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("微軟正黑體", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(226)))), ((int)(((byte)(211)))));
            this.label1.Location = new System.Drawing.Point(12, 31);
            this.label1.Name = "label1";
            this.label1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label1.Size = new System.Drawing.Size(145, 40);
            this.label1.TabIndex = 28;
            this.label1.Text = "個人資料";
            // 
            // MyPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(552, 535);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnEnter);
            this.Controls.Add(this.pictUser);
            this.Controls.Add(this.btnIntro);
            this.Controls.Add(this.btnLogout);
            this.Controls.Add(this.lblCardU);
            this.Controls.Add(this.lblTimeU);
            this.Controls.Add(this.lblCoinU);
            this.Controls.Add(this.lblNickameU);
            this.Controls.Add(this.lblUserIdU);
            this.Controls.Add(this.lblCard);
            this.Controls.Add(this.lblTime);
            this.Controls.Add(this.lblCoin);
            this.Controls.Add(this.lblNickname);
            this.Controls.Add(this.lblUserID);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "MyPage";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "\"Hello World - Taiwan!\"";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MyPage_FormClosing);
            this.Load += new System.EventHandler(this.MyPage_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictUser)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblCoin;
        private System.Windows.Forms.Label lblNickname;
        private System.Windows.Forms.Label lblUserID;
        private System.Windows.Forms.Label lblTime;
        private System.Windows.Forms.Label lblCard;
        private System.Windows.Forms.Label lblTimeU;
        private System.Windows.Forms.Label lblCoinU;
        private System.Windows.Forms.Label lblNickameU;
        private System.Windows.Forms.Label lblUserIdU;
        private System.Windows.Forms.Label lblCardU;
        private System.Windows.Forms.Button btnIntro;
        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.PictureBox pictUser;
        private System.Windows.Forms.Button btnEnter;
        private System.Windows.Forms.Label label1;
    }
}