# VRProject_WebForm
This is a web form project about a VR game which is developed by VisualStudio

## Basic Page
1. Top Page
  - User can sign up in this page
  - Tap Login button to redirect to My Page
  - Tap Intro button to redirect to Intro Page
  - Tap Signup button to sign up
2. My Page
  - User can view their own infomation in this page
  - Tap Logout button to redirect to Top Page
  - Tap Intro button to redirect to Intro Page
3. Login By Card
  - User can Login by card in this page
  - Tap "Login by account" button to switch to LoginByAccount Page
  - Tap "Back to Top Page" button to redirect to Top Page
4. Login By Account
  - User can Login by account in this page
  - Tap "Login by card" button to switch to LoginByCard Page
  - Tap "Back to Top Page" button to redirect to Top Page
5. Intro Page (TODO)
  - There is a web in this form
