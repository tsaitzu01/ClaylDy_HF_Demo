﻿using ClarIDy_HF_Demo;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace ClarIDy_HF_DEMO
{
    public partial class MyPage : Form
    {
        MySqlConnection connection;
        string card_num = "";
        string userEmail = "";
        string gender;

        public MyPage(string user)
        {
            InitializeComponent();
            string connectionString = "server=120.126.18.177; database=player; uid=root; pwd=root"; 
            //string connectionString = "server=192.168.231.98; database=player; uid=root; pwd=root";
            connection = new MySqlConnection(connectionString);
            bool isEmail = Regex.IsMatch(user, @"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z", RegexOptions.IgnoreCase);
            if (!isEmail)
                card_num = user;
            else
                userEmail = user;
        }

        private void MyPage_Load(object sender, EventArgs e)
        {
            if (userEmail == string.Empty)
            {
                string selectEmail = "select email from player_data where card_num = @card_num";
                MySqlCommand command2 = new MySqlCommand(selectEmail, connection);
                command2.Parameters.AddWithValue("@card_num", card_num);
                connection.Open();
                Object email = command2.ExecuteScalar();
                userEmail = email.ToString();
                connection.Close();
            }
            string UserInfo = "select * from player_data where email = @email";
            MySqlCommand command = new MySqlCommand(UserInfo, connection);
            command.Parameters.AddWithValue("@email", userEmail);
            connection.Open();
            MySqlDataReader Info = command.ExecuteReader();
            while (Info.Read())
            {
                lblNickameU.Text = Info["name"].ToString();
                lblUserIdU.Text = Info["email"].ToString();
                lblCardU.Text = Info["card_num"].ToString();
                gender = Info["gender"].ToString();
            }
            connection.Close();
            if (gender == "0")
                pictUser.Image = System.Drawing.Image.FromFile("C:\\Users\\User\\Downloads\\ClarIDy_HF_Demo A.4\\Photo\\男-removebg-preview.png");
            else
                pictUser.Image = System.Drawing.Image.FromFile("C:\\Users\\User\\Downloads\\ClarIDy_HF_Demo A.4\\Photo\\女-removebg-preview.png");
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            LoginByCard frm = new LoginByCard();
            frm.Show();
            this.Hide();
        }

        private void btnIntro_Click(object sender, EventArgs e)
        {
            IntroPage frm = new IntroPage();
            frm.Show();
            //this.Hide();
        }

        private void pictUser_Click(object sender, EventArgs e)
        {

        }

        private void lblNickameU_Click(object sender, EventArgs e)
        {

        }

        private void MyPage_FormClosing(object sender, FormClosingEventArgs e)
        {
            System.Environment.Exit(0);
        }

        private void btnEnter_Click(object sender, EventArgs e)
        {
            StreamWriter sw = new StreamWriter(@"C:\Users\User\Downloads\ClarIDy_HF_Demo A.4\UserInfo.txt");
            sw.Write("/" + lblNickameU.Text);
            sw.Write("/" + lblUserIdU.Text);
            sw.Write("/" + lblCardU.Text);
            sw.Write("/" + gender);
            sw.Write("/" + lblCoinU.Text);
            sw.Write("/" + lblTimeU.Text);
            sw.Close();
            Process.Start(@"D:\GoodProject\GoodProject.uproject");
        }
    }
}
