﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using MySql.Data.MySqlClient;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using RFID_HF_SDK;

using System.Runtime.InteropServices;
using System.Threading;
using System.Collections;

namespace ClarIDy_HF_Demo
{
    public partial class frmMain : Form
    {

        [DllImport("kernel32.dll")]
        extern static short QueryPerformanceCounter(ref long x);
        [DllImport("kernel32.dll")]
        extern static short QueryPerformanceFrequency(ref long x);

        #region Win32
        [DllImport("user32.dll")]
        static extern void MessageBeep(uint uType);

        const uint MB_OK = 0x00000000;

        const uint MB_ICONHAND = 0x00000010;
        const uint MB_ICONQUESTION = 0x00000020;
        const uint MB_ICONEXCLAMATION = 0x00000030;
        const uint MB_ICONASTERISK = 0x00000040;

        const byte IO_LED = 0x04;
        const byte IO_BEEP = 0x05;
        #endregion

        public DataSet m_datasetUID = null;
        public DataSet m_datasetBlockData = null;
        int m_iHandle = -1;
        

        #region Form Controls
        public frmMain()
        {
            InitializeComponent();
            //string connString = "server=127.0.0.1;port=3306;user id=root;password=***;database=mvctest;charset=utf8;";
            //MySqlConnection conn = new MySqlConnection(connString);
            //conn.Open();
        }

        private void frmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (m_iHandle >= 0)
                RFID_HF_SDK.RFID_HF_API.RFID_HF_Disconnect(m_iHandle);
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            
            m_datasetUID = new DataSet();
            m_datasetUID.Tables.Add("ReadUID");

            DataColumn dcColumn;

            dcColumn = new DataColumn();
            dcColumn.ColumnName = "UID";
            dcColumn.DataType = System.Type.GetType("System.String");
            dcColumn.AllowDBNull = true;
            m_datasetUID.Tables[0].Columns.Add(dcColumn);

            dcColumn = new DataColumn();
            dcColumn.ColumnName = "Count";
            dcColumn.DataType = System.Type.GetType("System.Int64");
            dcColumn.AllowDBNull = true;
            m_datasetUID.Tables[0].Columns.Add(dcColumn);

            dcColumn = new DataColumn();
            dcColumn.ColumnName = "Protocol";
            dcColumn.DataType = System.Type.GetType("System.String");
            dcColumn.AllowDBNull = true;
            m_datasetUID.Tables[0].Columns.Add(dcColumn);

            m_datasetUID.Tables[0].PrimaryKey = new DataColumn[] { m_datasetUID.Tables[0].Columns[0] };
            comboBox1.SelectedIndex = 0;
            
        }
        #endregion

        #region Button Controls
        
        private void btnInventoryClear_Click(object sender, EventArgs e)
        {
            dgInventory.DataSource = null;
            m_datasetUID.Tables[0].Rows.Clear();
        }
        
        
        
        private void btnConnect_Click(object sender, EventArgs e)
        {
            btnConnect.Enabled = false;
            int iType = 0;
            int iPort = int.Parse(comboConnectPort.Text);
            int iBaudRate = 115200;
            
            if (comboConnectType.Text == "USB")
            {
                iType = 4;
                m_iHandle = RFID_HF_API.RFID_HF_Connect(iType, iPort, iBaudRate); //for USB
            }
            else if (comboConnectType.Text == "UART")
            {
                iType = 1;
                iBaudRate = int.Parse(comboConnectBaudRate.Text);
                m_iHandle = RFID_HF_API.RFID_HF_Connect(iType, iPort, iBaudRate); //for Uart
            }

            if (m_iHandle >= 0)
            {
                int iModel = CheckModel();

                if (iModel >= 0)
                {
                    labelConStatus.Text = "Connected";
                    btnDisconnect.Enabled = true;
                    btnInventoryRead.Enabled = true;
                    btnInventoryStop.Enabled = true;

                    GetVersion(comboBox1.SelectedIndex);
                }
                else
                {
                    labelConStatus.Text = "Failed to Connect";
                    btnConnect.Enabled = true;
                    btnInventoryRead.Enabled = false;
                    btnInventoryStop.Enabled = false;
                }
            }
            else
            {
                labelConStatus.Text = "Failed to Connect";
                btnConnect.Enabled = true;
                btnInventoryRead.Enabled = false;
                btnInventoryStop.Enabled = false;

                m_iHandle = -1;
            }
        }

        private void btnDisconnect_Click(object sender, EventArgs e)
        {
            if (timer1.Enabled == true)
                MessageBox.Show("Please Stop Inventory !!");
            else
            {
                int Res = RFID_HF_API.RFID_HF_Disconnect(m_iHandle);
                m_iHandle = -1;
                labelConStatus.Text = "Disconnected";
                btnDisconnect.Enabled = false;
                btnConnect.Enabled = true;

                btnInventoryRead.Enabled = false;
                btnInventoryStop.Enabled = false;
            }
        }

        private void btnInventoryRead_Click(object sender, EventArgs e)
        {
            btnInventoryRead.Enabled = false;
            checkISO15693.Enabled = false;
            checkISO14443A.Enabled = false;
            checkISO14443B.Enabled = false;
            checkFeliCa.Enabled = false;
            //btnReceive.Enabled = false;
            //btnSend.Enabled = false;
            timer1.Enabled = true;
        }

        private void btnInventoryStop_Click(object sender, EventArgs e)
        {
            timer1.Enabled = false;
            btnInventoryRead.Enabled = true;
            checkISO15693.Enabled = true;
            checkISO14443A.Enabled = true;
            checkISO14443B.Enabled = true;
            checkFeliCa.Enabled = true;
            //btnReceive.Enabled = true;
            //btnSend.Enabled = true;
        }
        #endregion

        private int CheckModel()
        {
            int iModel = RFID_HF_API.RFID_GetReaderModel(m_iHandle);

            if (iModel == 0)
            {
                labelModel.Text = "1";

                checkISO14443A.Enabled = true;
                checkISO14443A.Checked = true;
                checkISO14443B.Enabled = true;
                checkISO14443B.Checked = true;
                checkISO15693.Enabled = true;
                checkISO15693.Checked = true;
                checkFeliCa.Enabled = true;
                checkFeliCa.Checked = true;
                //btnSend.Enabled = true;
                //btnReceive.Enabled = true;
            }
            else if (iModel == 1)
            {
                labelModel.Text = "2";

                checkISO14443A.Enabled = true;
                checkISO14443A.Checked = true;
                checkISO14443B.Enabled = true;
                checkISO14443B.Checked = true;
                checkISO15693.Enabled = true;
                checkISO15693.Checked = true;
                checkFeliCa.Enabled = true;
                checkFeliCa.Checked = true;
                //btnSend.Enabled = false;
                //btnReceive.Enabled = false; ;
            }
            else if (iModel == 2)
            {
                labelModel.Text = "3";

                checkISO14443A.Enabled = true;
                checkISO14443A.Checked = true;
                checkISO14443B.Enabled = false;
                checkISO14443B.Checked = false;
                checkISO15693.Enabled = true;
                checkISO15693.Checked = true;
                checkFeliCa.Enabled = false;
                checkFeliCa.Checked = false;
                //btnSend.Enabled = false;
                //btnReceive.Enabled = false; ;
            }
            return iModel;
        }

        private void GetVersion(int Mode)
        {
            byte[] data = new byte[40];
            string version = "";
            int len = RFID_HF_API.RFID_GetVersion(m_iHandle, data, Mode);
            if (len > 0)
            {
                if (Mode != 1)
                {
                    System.Text.ASCIIEncoding asciiEncoding = new System.Text.ASCIIEncoding();
                    version = asciiEncoding.GetString(data);
                }
                else
                {
                    version = data[0].ToString() + "." + data[1].ToString();
                    version += " " + data[3].ToString().PadLeft(2, '0') + "/" + data[4].ToString().PadLeft(2, '0') + "/20" + data[5].ToString().PadLeft(2, '0');
                    version += " " + data[6].ToString().PadLeft(2, '0') + ":" + data[7].ToString().PadLeft(2, '0') + ":" + data[8].ToString().PadLeft(2, '0');
                }
            }
            this.lbVer.Text = version;
        }

        #region Timer Controls
        private void timer1_Tick(object sender, EventArgs e)
        {
            int iTagCount = Get_UID();
            if (iTagCount > 0)
            {
               // Beep(10);
                //LEDON(10);
                dgInventory.DataSource = m_datasetUID.Tables[0];
            }
        }
        #endregion


        #region Function Controls
        private void CreatTable(int BytePerBlk, string Protocol)
        {
            m_datasetBlockData = new DataSet();
            m_datasetBlockData.Tables.Add("Blk");

            DataColumn dcColumn;
            dcColumn = new DataColumn();
            dcColumn.ColumnName = "Blk";
            dcColumn.DataType = System.Type.GetType("System.Int16");
            dcColumn.AllowDBNull = true;
            m_datasetBlockData.Tables["Blk"].Columns.Add(dcColumn);

            for (int i = 0; i < BytePerBlk; i++)
            {
                dcColumn = new DataColumn();
                dcColumn.ColumnName = "Data" + i.ToString();
                dcColumn.DataType = System.Type.GetType("System.String");
                dcColumn.AllowDBNull = true;
                m_datasetBlockData.Tables["Blk"].Columns.Add(dcColumn);
            }

            if (Protocol == "ISO15693")
            {
                dcColumn = new DataColumn();
                dcColumn.ColumnName = "Status";
                dcColumn.DataType = System.Type.GetType("System.String");
                dcColumn.AllowDBNull = true;
                m_datasetBlockData.Tables["Blk"].Columns.Add(dcColumn);
            }

            m_datasetBlockData.Tables["Blk"].PrimaryKey = new DataColumn[] { m_datasetBlockData.Tables["Blk"].Columns[0] };
        }

        private bool Filter(string uid)
        {
            try
            {
                bool res = true;

                DataRow[] dr = m_datasetUID.Tables[0].Select("UID = '" + uid + "'");
                if (dr.Length > 0)
                {
                    long readcount = long.Parse(dr[0]["count"].ToString());
                    readcount++;
                    dr[0]["count"] = readcount.ToString();
                    res = false;   //if epc exist,then break
                    m_datasetUID.Tables[0].AcceptChanges();
                }
                return res;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        private int Get_UID()
        {
            string sUID = "";
            uint TotalCnt = 0;
            byte TagNo = 0;
            int i, j, Res; //, tagcount
            byte[] uid = new byte[160];
            byte[] UIDLen = new byte[8];
            byte[] cid = new byte[8];

            if (checkISO15693.Checked)
            {
                TagNo = (byte)RFID_HF_SDK.RFID_HF_API.RFID_15693_ReadMultiUID(m_iHandle, 0xCC, 0, uid);
                //TagNo = (byte)RFID_HF_API.RFID_15693_ReadUID(m_iHandle, 0x000C, 0, uid);

                TotalCnt += TagNo;
                for (int count = 0; count < TagNo; count++)
                {
                    string buf = "";
                    for (i = 0; i < 8; i++)
                        buf += uid[count * 8 + i].ToString("X").PadLeft(2, '0');
                    sUID = buf.Replace("-", "");
                    if (Filter(sUID))
                    {
                        DataRow drNew = m_datasetUID.Tables[0].NewRow();
                        drNew["UID"] = sUID;
                        drNew["Protocol"] = "ISO15693";
                        drNew["Count"] = "1";
                        m_datasetUID.Tables[0].Rows.Add(drNew);
                    }
                }
            }

            if (checkISO14443A.Checked)
            {
                Res = RFID_HF_API.RFID_14443A_ReadUID(m_iHandle, ref TagNo, UIDLen, uid);
                if (Res == 0)
                {
                    TotalCnt += TagNo;
                    for (i = 0; i < TagNo; i++)
                    {
                        sUID = "";
                        if (UIDLen[i] > 0)
                        {
                            for (j = 0; j < UIDLen[i]; j++)
                            {
                                sUID += uid[i * 10 + (UIDLen[i] - 1) - j].ToString("X").PadLeft(2, '0');
                            }
                            if (Filter(sUID))
                            {
                                DataRow drNew = m_datasetUID.Tables[0].NewRow();
                                drNew["UID"] = sUID;
                                drNew["Protocol"] = "ISO14443A";
                                drNew["Count"] = "1";
                                m_datasetUID.Tables[0].Rows.Add(drNew);
                            }
                        }
                    }
                }
            }

            if (checkISO14443B.Checked)
            {
                
                Res = RFID_HF_API.RFID_14443B_ReadUID(m_iHandle, ref TagNo, uid);
                if (Res == 0)
                {
                    TotalCnt += TagNo;
                    for (i = 0; i < TagNo; i++)
                    {
                        sUID = "";
                        for (j = 0; j < 8; j++)
                        {
                            sUID += uid[i * 8 + j].ToString("X").PadLeft(2, '0');
                        }
                        if (Filter(sUID))
                        {
                            DataRow drNew = m_datasetUID.Tables[0].NewRow();
                            drNew["UID"] = sUID;
                            drNew["Protocol"] = "ISO14443B";
                            drNew["Count"] = "1";
                            m_datasetUID.Tables[0].Rows.Add(drNew);
                        }
                    }
                }
            }
            return (int)TotalCnt;
        }
        #endregion
        

        private void comboConnectType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboConnectType.SelectedIndex == 0)
                comboConnectBaudRate.Enabled = false;
            else if (comboConnectType.SelectedIndex == 1)
            {
                comboConnectBaudRate.SelectedIndex = 4;
                comboConnectBaudRate.Enabled = true;
            }
        }
        
    }
}
