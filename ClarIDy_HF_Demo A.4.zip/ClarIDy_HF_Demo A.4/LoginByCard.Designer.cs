﻿namespace ClarIDy_HF_DEMO
{
    partial class LoginByCard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LoginByCard));
            this.lblRfid = new System.Windows.Forms.Label();
            this.txbRfid = new System.Windows.Forms.TextBox();
            this.lblByCard = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.lblTest = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnIntro = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblRfid
            // 
            this.lblRfid.AutoSize = true;
            this.lblRfid.BackColor = System.Drawing.Color.Transparent;
            this.lblRfid.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblRfid.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lblRfid.Location = new System.Drawing.Point(39, 125);
            this.lblRfid.Name = "lblRfid";
            this.lblRfid.Size = new System.Drawing.Size(74, 21);
            this.lblRfid.TabIndex = 16;
            this.lblRfid.Text = "學生證：";
            // 
            // txbRfid
            // 
            this.txbRfid.BackColor = System.Drawing.SystemColors.Info;
            this.txbRfid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txbRfid.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txbRfid.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.txbRfid.Location = new System.Drawing.Point(119, 125);
            this.txbRfid.Name = "txbRfid";
            this.txbRfid.Size = new System.Drawing.Size(131, 22);
            this.txbRfid.TabIndex = 15;
            this.txbRfid.Click += new System.EventHandler(this.txbRfid_MouseClick);
            this.txbRfid.MouseClick += new System.Windows.Forms.MouseEventHandler(this.txbRfid_MouseClick);
            this.txbRfid.TextChanged += new System.EventHandler(this.txbRfid_TextChanged);
            // 
            // lblByCard
            // 
            this.lblByCard.AutoSize = true;
            this.lblByCard.BackColor = System.Drawing.Color.Transparent;
            this.lblByCard.Font = new System.Drawing.Font("微軟正黑體", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblByCard.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lblByCard.Location = new System.Drawing.Point(163, 197);
            this.lblByCard.Name = "lblByCard";
            this.lblByCard.Size = new System.Drawing.Size(90, 21);
            this.lblByCard.TabIndex = 14;
            this.lblByCard.Text = "以帳號登入";
            this.lblByCard.Click += new System.EventHandler(this.lblByCard_Click);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // lblTest
            // 
            this.lblTest.AutoSize = true;
            this.lblTest.BackColor = System.Drawing.Color.Transparent;
            this.lblTest.Font = new System.Drawing.Font("微軟正黑體", 12F);
            this.lblTest.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lblTest.Location = new System.Drawing.Point(116, 153);
            this.lblTest.Name = "lblTest";
            this.lblTest.Size = new System.Drawing.Size(0, 20);
            this.lblTest.TabIndex = 19;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("微軟正黑體", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(226)))), ((int)(((byte)(211)))));
            this.label1.Location = new System.Drawing.Point(216, 9);
            this.label1.Name = "label1";
            this.label1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label1.Size = new System.Drawing.Size(81, 40);
            this.label1.TabIndex = 23;
            this.label1.Text = "登入";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("微軟正黑體", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label2.Location = new System.Drawing.Point(169, 220);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 21);
            this.label2.TabIndex = 24;
            this.label2.Text = "尚未註冊?";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // btnIntro
            // 
            this.btnIntro.BackColor = System.Drawing.Color.Tan;
            this.btnIntro.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnIntro.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnIntro.Location = new System.Drawing.Point(35, 199);
            this.btnIntro.Margin = new System.Windows.Forms.Padding(4);
            this.btnIntro.Name = "btnIntro";
            this.btnIntro.Size = new System.Drawing.Size(121, 37);
            this.btnIntro.TabIndex = 27;
            this.btnIntro.Text = "遊戲介紹";
            this.btnIntro.UseVisualStyleBackColor = false;
            this.btnIntro.Click += new System.EventHandler(this.btnIntro_Click);
            // 
            // LoginByCard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(309, 282);
            this.Controls.Add(this.btnIntro);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblTest);
            this.Controls.Add(this.lblRfid);
            this.Controls.Add(this.txbRfid);
            this.Controls.Add(this.lblByCard);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "LoginByCard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "\"Hello World - Taiwan!\"";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.LoginByCard_FormClosing_1);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblRfid;
        private System.Windows.Forms.TextBox txbRfid;
        private System.Windows.Forms.Label lblByCard;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label lblTest;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnIntro;
    }
}