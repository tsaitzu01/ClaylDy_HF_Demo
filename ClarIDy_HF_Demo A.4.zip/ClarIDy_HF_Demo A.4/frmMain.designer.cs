﻿namespace ClarIDy_HF_Demo
{
    partial class frmMain
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改這個方法的內容。
        ///
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panelMain = new System.Windows.Forms.Panel();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.lbVer = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.checkISO15693 = new System.Windows.Forms.CheckBox();
            this.checkFeliCa = new System.Windows.Forms.CheckBox();
            this.checkISO14443A = new System.Windows.Forms.CheckBox();
            this.checkISO14443B = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.labelModel = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.comboConnectBaudRate = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.btnConnect = new System.Windows.Forms.Button();
            this.comboConnectType = new System.Windows.Forms.ComboBox();
            this.labelConStatus = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btnDisconnect = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.comboConnectPort = new System.Windows.Forms.ComboBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.tabMain = new System.Windows.Forms.TabControl();
            this.tabPageInventory = new System.Windows.Forms.TabPage();
            this.dgInventory = new System.Windows.Forms.DataGridView();
            this.btnInventoryStop = new System.Windows.Forms.Button();
            this.btnInventoryClear = new System.Windows.Forms.Button();
            this.btnInventoryRead = new System.Windows.Forms.Button();
            this.timer43B = new System.Windows.Forms.Timer(this.components);
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.timer_Beep = new System.Windows.Forms.Timer(this.components);
            this.timer_LED = new System.Windows.Forms.Timer(this.components);
            this.radioNormal = new System.Windows.Forms.RadioButton();
            this.radioOption = new System.Windows.Forms.RadioButton();
            this.radioFujitsu = new System.Windows.Forms.RadioButton();
            this.radioSecure = new System.Windows.Forms.RadioButton();
            this.label14 = new System.Windows.Forms.Label();
            this.rdo32 = new System.Windows.Forms.RadioButton();
            this.textPassword = new System.Windows.Forms.TextBox();
            this.rdo64 = new System.Windows.Forms.RadioButton();
            this.label15 = new System.Windows.Forms.Label();
            this.panelMain.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tabMain.SuspendLayout();
            this.tabPageInventory.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgInventory)).BeginInit();
            this.SuspendLayout();
            // 
            // panelMain
            // 
            this.panelMain.Controls.Add(this.groupBox5);
            this.panelMain.Controls.Add(this.groupBox2);
            this.panelMain.Controls.Add(this.groupBox1);
            this.panelMain.Controls.Add(this.pictureBox1);
            this.panelMain.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelMain.Location = new System.Drawing.Point(0, 0);
            this.panelMain.Name = "panelMain";
            this.panelMain.Size = new System.Drawing.Size(195, 446);
            this.panelMain.TabIndex = 1;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.comboBox1);
            this.groupBox5.Controls.Add(this.lbVer);
            this.groupBox5.Location = new System.Drawing.Point(12, 367);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(174, 77);
            this.groupBox5.TabIndex = 20;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Version";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "RFID HF SDK",
            "Firmware",
            "ISO 15603",
            "ISO 14443",
            "P2P",
            "Secure",
            "About ClarIDy HF Demo"});
            this.comboBox1.Location = new System.Drawing.Point(13, 21);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 20);
            this.comboBox1.TabIndex = 2;
            // 
            // lbVer
            // 
            this.lbVer.AutoSize = true;
            this.lbVer.Location = new System.Drawing.Point(14, 54);
            this.lbVer.Name = "lbVer";
            this.lbVer.Size = new System.Drawing.Size(0, 12);
            this.lbVer.TabIndex = 1;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.checkISO15693);
            this.groupBox2.Controls.Add(this.checkFeliCa);
            this.groupBox2.Controls.Add(this.checkISO14443A);
            this.groupBox2.Controls.Add(this.checkISO14443B);
            this.groupBox2.Location = new System.Drawing.Point(10, 256);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(95, 105);
            this.groupBox2.TabIndex = 19;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Tag Type";
            // 
            // checkISO15693
            // 
            this.checkISO15693.AutoSize = true;
            this.checkISO15693.Checked = true;
            this.checkISO15693.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkISO15693.Location = new System.Drawing.Point(8, 17);
            this.checkISO15693.Name = "checkISO15693";
            this.checkISO15693.Size = new System.Drawing.Size(75, 16);
            this.checkISO15693.TabIndex = 7;
            this.checkISO15693.Text = "ISO 15693";
            this.checkISO15693.UseVisualStyleBackColor = true;
            // 
            // checkFeliCa
            // 
            this.checkFeliCa.AutoSize = true;
            this.checkFeliCa.Checked = true;
            this.checkFeliCa.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkFeliCa.Location = new System.Drawing.Point(8, 80);
            this.checkFeliCa.Name = "checkFeliCa";
            this.checkFeliCa.Size = new System.Drawing.Size(54, 16);
            this.checkFeliCa.TabIndex = 13;
            this.checkFeliCa.Text = "FeliCa";
            this.checkFeliCa.UseVisualStyleBackColor = true;
            // 
            // checkISO14443A
            // 
            this.checkISO14443A.AutoSize = true;
            this.checkISO14443A.Checked = true;
            this.checkISO14443A.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkISO14443A.Location = new System.Drawing.Point(8, 38);
            this.checkISO14443A.Name = "checkISO14443A";
            this.checkISO14443A.Size = new System.Drawing.Size(83, 16);
            this.checkISO14443A.TabIndex = 8;
            this.checkISO14443A.Text = "ISO 14443A";
            this.checkISO14443A.UseVisualStyleBackColor = true;
            // 
            // checkISO14443B
            // 
            this.checkISO14443B.AutoSize = true;
            this.checkISO14443B.Checked = true;
            this.checkISO14443B.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkISO14443B.Location = new System.Drawing.Point(8, 59);
            this.checkISO14443B.Name = "checkISO14443B";
            this.checkISO14443B.Size = new System.Drawing.Size(83, 16);
            this.checkISO14443B.TabIndex = 9;
            this.checkISO14443B.Text = "ISO 14443B";
            this.checkISO14443B.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.labelModel);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.comboConnectBaudRate);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.btnConnect);
            this.groupBox1.Controls.Add(this.comboConnectType);
            this.groupBox1.Controls.Add(this.labelConStatus);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.btnDisconnect);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.comboConnectPort);
            this.groupBox1.Location = new System.Drawing.Point(9, 73);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(174, 174);
            this.groupBox1.TabIndex = 18;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Connect";
            // 
            // labelModel
            // 
            this.labelModel.AutoSize = true;
            this.labelModel.Location = new System.Drawing.Point(68, 154);
            this.labelModel.Name = "labelModel";
            this.labelModel.Size = new System.Drawing.Size(0, 12);
            this.labelModel.TabIndex = 16;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(18, 154);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(35, 12);
            this.label6.TabIndex = 15;
            this.label6.Text = "Model";
            // 
            // comboConnectBaudRate
            // 
            this.comboConnectBaudRate.Enabled = false;
            this.comboConnectBaudRate.FormattingEnabled = true;
            this.comboConnectBaudRate.Items.AddRange(new object[] {
            "4800",
            "9600",
            "19200",
            "38400",
            "115200"});
            this.comboConnectBaudRate.Location = new System.Drawing.Point(75, 68);
            this.comboConnectBaudRate.Name = "comboConnectBaudRate";
            this.comboConnectBaudRate.Size = new System.Drawing.Size(89, 20);
            this.comboConnectBaudRate.TabIndex = 14;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(17, 71);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(50, 12);
            this.label5.TabIndex = 13;
            this.label5.Text = "Baudrate:";
            // 
            // btnConnect
            // 
            this.btnConnect.Location = new System.Drawing.Point(9, 114);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(75, 30);
            this.btnConnect.TabIndex = 4;
            this.btnConnect.Text = "Connect";
            this.btnConnect.UseVisualStyleBackColor = true;
            this.btnConnect.Click += new System.EventHandler(this.btnConnect_Click);
            // 
            // comboConnectType
            // 
            this.comboConnectType.FormattingEnabled = true;
            this.comboConnectType.Items.AddRange(new object[] {
            "USB",
            "UART"});
            this.comboConnectType.Location = new System.Drawing.Point(75, 19);
            this.comboConnectType.Name = "comboConnectType";
            this.comboConnectType.Size = new System.Drawing.Size(89, 20);
            this.comboConnectType.TabIndex = 0;
            this.comboConnectType.Text = "USB";
            this.comboConnectType.SelectedIndexChanged += new System.EventHandler(this.comboConnectType_SelectedIndexChanged);
            // 
            // labelConStatus
            // 
            this.labelConStatus.AutoSize = true;
            this.labelConStatus.ForeColor = System.Drawing.Color.Red;
            this.labelConStatus.Location = new System.Drawing.Point(73, 96);
            this.labelConStatus.Name = "labelConStatus";
            this.labelConStatus.Size = new System.Drawing.Size(67, 12);
            this.labelConStatus.TabIndex = 11;
            this.labelConStatus.Text = "Disconnected";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(17, 96);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(32, 12);
            this.label4.TabIndex = 10;
            this.label4.Text = "Status";
            // 
            // btnDisconnect
            // 
            this.btnDisconnect.Enabled = false;
            this.btnDisconnect.Location = new System.Drawing.Point(88, 114);
            this.btnDisconnect.Name = "btnDisconnect";
            this.btnDisconnect.Size = new System.Drawing.Size(75, 30);
            this.btnDisconnect.TabIndex = 12;
            this.btnDisconnect.Text = "Disconnect";
            this.btnDisconnect.UseVisualStyleBackColor = true;
            this.btnDisconnect.Click += new System.EventHandler(this.btnDisconnect_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(17, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(32, 12);
            this.label1.TabIndex = 1;
            this.label1.Text = "Type:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(17, 47);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(27, 12);
            this.label2.TabIndex = 2;
            this.label2.Text = "Port:";
            // 
            // comboConnectPort
            // 
            this.comboConnectPort.FormattingEnabled = true;
            this.comboConnectPort.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6"});
            this.comboConnectPort.Location = new System.Drawing.Point(75, 44);
            this.comboConnectPort.Name = "comboConnectPort";
            this.comboConnectPort.Size = new System.Drawing.Size(89, 20);
            this.comboConnectPort.TabIndex = 3;
            this.comboConnectPort.Text = "0";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(25, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(149, 53);
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // tabMain
            // 
            this.tabMain.Controls.Add(this.tabPageInventory);
            this.tabMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabMain.Location = new System.Drawing.Point(195, 0);
            this.tabMain.Name = "tabMain";
            this.tabMain.SelectedIndex = 0;
            this.tabMain.Size = new System.Drawing.Size(547, 446);
            this.tabMain.TabIndex = 2;
            // 
            // tabPageInventory
            // 
            this.tabPageInventory.Controls.Add(this.dgInventory);
            this.tabPageInventory.Controls.Add(this.btnInventoryStop);
            this.tabPageInventory.Controls.Add(this.btnInventoryClear);
            this.tabPageInventory.Controls.Add(this.btnInventoryRead);
            this.tabPageInventory.Location = new System.Drawing.Point(4, 22);
            this.tabPageInventory.Name = "tabPageInventory";
            this.tabPageInventory.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageInventory.Size = new System.Drawing.Size(539, 420);
            this.tabPageInventory.TabIndex = 0;
            this.tabPageInventory.Text = "Inventory";
            this.tabPageInventory.UseVisualStyleBackColor = true;
            // 
            // dgInventory
            // 
            this.dgInventory.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgInventory.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgInventory.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgInventory.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgInventory.Location = new System.Drawing.Point(11, 42);
            this.dgInventory.Name = "dgInventory";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgInventory.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgInventory.RowTemplate.Height = 24;
            this.dgInventory.Size = new System.Drawing.Size(346, 335);
            this.dgInventory.TabIndex = 14;
            // 
            // btnInventoryStop
            // 
            this.btnInventoryStop.Enabled = false;
            this.btnInventoryStop.Location = new System.Drawing.Point(138, 9);
            this.btnInventoryStop.Name = "btnInventoryStop";
            this.btnInventoryStop.Size = new System.Drawing.Size(91, 28);
            this.btnInventoryStop.TabIndex = 13;
            this.btnInventoryStop.Text = "Stop";
            this.btnInventoryStop.UseVisualStyleBackColor = true;
            this.btnInventoryStop.Click += new System.EventHandler(this.btnInventoryStop_Click);
            // 
            // btnInventoryClear
            // 
            this.btnInventoryClear.Location = new System.Drawing.Point(265, 9);
            this.btnInventoryClear.Name = "btnInventoryClear";
            this.btnInventoryClear.Size = new System.Drawing.Size(91, 28);
            this.btnInventoryClear.TabIndex = 12;
            this.btnInventoryClear.Text = "Clear";
            this.btnInventoryClear.UseVisualStyleBackColor = true;
            // 
            // btnInventoryRead
            // 
            this.btnInventoryRead.Enabled = false;
            this.btnInventoryRead.Location = new System.Drawing.Point(11, 9);
            this.btnInventoryRead.Name = "btnInventoryRead";
            this.btnInventoryRead.Size = new System.Drawing.Size(91, 28);
            this.btnInventoryRead.TabIndex = 11;
            this.btnInventoryRead.Text = "Inventory";
            this.btnInventoryRead.UseVisualStyleBackColor = true;
            this.btnInventoryRead.Click += new System.EventHandler(this.btnInventoryRead_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // timer_Beep
            // 
            this.timer_Beep.Interval = 300;
            // 
            // radioNormal
            // 
            this.radioNormal.AutoSize = true;
            this.radioNormal.Checked = true;
            this.radioNormal.Location = new System.Drawing.Point(6, 13);
            this.radioNormal.Name = "radioNormal";
            this.radioNormal.Size = new System.Drawing.Size(58, 16);
            this.radioNormal.TabIndex = 0;
            this.radioNormal.TabStop = true;
            this.radioNormal.Text = "Normal";
            this.radioNormal.UseVisualStyleBackColor = true;
            // 
            // radioOption
            // 
            this.radioOption.AutoSize = true;
            this.radioOption.Location = new System.Drawing.Point(6, 32);
            this.radioOption.Name = "radioOption";
            this.radioOption.Size = new System.Drawing.Size(113, 16);
            this.radioOption.TabIndex = 1;
            this.radioOption.Text = "Option Flag Enable";
            this.radioOption.UseVisualStyleBackColor = true;
            // 
            // radioFujitsu
            // 
            this.radioFujitsu.AutoSize = true;
            this.radioFujitsu.Location = new System.Drawing.Point(6, 51);
            this.radioFujitsu.Name = "radioFujitsu";
            this.radioFujitsu.Size = new System.Drawing.Size(108, 16);
            this.radioFujitsu.TabIndex = 2;
            this.radioFujitsu.Text = "Fujitsu_Fast Mode";
            this.radioFujitsu.UseVisualStyleBackColor = true;
            // 
            // radioSecure
            // 
            this.radioSecure.AutoSize = true;
            this.radioSecure.Location = new System.Drawing.Point(6, 70);
            this.radioSecure.Name = "radioSecure";
            this.radioSecure.Size = new System.Drawing.Size(54, 16);
            this.radioSecure.TabIndex = 3;
            this.radioSecure.Text = "Secure";
            this.radioSecure.UseVisualStyleBackColor = true;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(8, 15);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(26, 12);
            this.label14.TabIndex = 0;
            // 
            // rdo32
            // 
            this.rdo32.AutoSize = true;
            this.rdo32.Location = new System.Drawing.Point(39, 15);
            this.rdo32.Name = "rdo32";
            this.rdo32.Size = new System.Drawing.Size(54, 16);
            this.rdo32.TabIndex = 1;
            this.rdo32.TabStop = true;
            this.rdo32.Text = "32 bits";
            this.rdo32.UseVisualStyleBackColor = true;
            // 
            // textPassword
            // 
            this.textPassword.Location = new System.Drawing.Point(41, 56);
            this.textPassword.Name = "textPassword";
            this.textPassword.Size = new System.Drawing.Size(84, 22);
            this.textPassword.TabIndex = 4;
            // 
            // rdo64
            // 
            this.rdo64.AutoSize = true;
            this.rdo64.Location = new System.Drawing.Point(39, 35);
            this.rdo64.Name = "rdo64";
            this.rdo64.Size = new System.Drawing.Size(54, 16);
            this.rdo64.TabIndex = 2;
            this.rdo64.TabStop = true;
            this.rdo64.Text = "64 bits";
            this.rdo64.UseVisualStyleBackColor = true;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(7, 59);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(30, 12);
            this.label15.TabIndex = 5;
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(742, 446);
            this.Controls.Add(this.tabMain);
            this.Controls.Add(this.panelMain);
            this.Name = "frmMain";
            this.Text = "ClarIDy HF RFID-NFC Demo";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.panelMain.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tabMain.ResumeLayout(false);
            this.tabPageInventory.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgInventory)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelMain;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label lbVer;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.CheckBox checkISO15693;
        private System.Windows.Forms.CheckBox checkFeliCa;
        private System.Windows.Forms.CheckBox checkISO14443A;
        private System.Windows.Forms.CheckBox checkISO14443B;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label labelModel;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox comboConnectBaudRate;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnConnect;
        private System.Windows.Forms.ComboBox comboConnectType;
        private System.Windows.Forms.Label labelConStatus;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnDisconnect;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboConnectPort;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TabControl tabMain;
        private System.Windows.Forms.Timer timer43B;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Timer timer_Beep;
        private System.Windows.Forms.Timer timer_LED;
        private System.Windows.Forms.TabPage tabPageInventory;
        private System.Windows.Forms.DataGridView dgInventory;
        private System.Windows.Forms.Button btnInventoryStop;
        private System.Windows.Forms.Button btnInventoryClear;
        private System.Windows.Forms.Button btnInventoryRead;
        private System.Windows.Forms.RadioButton radioNormal;
        private System.Windows.Forms.RadioButton radioOption;
        private System.Windows.Forms.RadioButton radioFujitsu;
        private System.Windows.Forms.RadioButton radioSecure;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.RadioButton rdo32;
        private System.Windows.Forms.TextBox textPassword;
        private System.Windows.Forms.RadioButton rdo64;
        private System.Windows.Forms.Label label15;
    }
}

