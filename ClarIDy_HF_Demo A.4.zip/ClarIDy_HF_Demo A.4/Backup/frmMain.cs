﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using RFID_HF_SDK;

using System.Runtime.InteropServices;
using System.Threading;
using System.Collections;

namespace ClarIDy_HF_Demo
{
    public partial class frmMain : Form
    {
        [DllImport("kernel32.dll")]
        extern static short QueryPerformanceCounter(ref long x);
        [DllImport("kernel32.dll")]
        extern static short QueryPerformanceFrequency(ref long x);

        #region Win32
        [DllImport("user32.dll")]
        static extern void MessageBeep(uint uType);

        const uint MB_OK = 0x00000000;

        const uint MB_ICONHAND = 0x00000010;
        const uint MB_ICONQUESTION = 0x00000020;
        const uint MB_ICONEXCLAMATION = 0x00000030;
        const uint MB_ICONASTERISK = 0x00000040;

        const byte IO_LED = 0x04;
        const byte IO_BEEP = 0x05;
        #endregion


        public DataSet m_datasetUID = null;
        public DataSet m_datasetBlockData = null;
        int m_iHandle = -1;
        
        long m_lStartTime = 0;
        long m_lEndTime = 0;
        long m_lFrequency = 0;

        //    bool m_bBeep = false;

        #region Form Controls
        public frmMain()
        {
            InitializeComponent();
        }

        private void frmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (m_iHandle >= 0)
                RFID_HF_SDK.RFID_HF_API.RFID_HF_Disconnect(m_iHandle);
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            m_datasetUID = new DataSet();
            m_datasetUID.Tables.Add("ReadUID");

            DataColumn dcColumn;

            dcColumn = new DataColumn();
            dcColumn.ColumnName = "UID";
            dcColumn.DataType = System.Type.GetType("System.String");
            dcColumn.AllowDBNull = true;
            m_datasetUID.Tables[0].Columns.Add(dcColumn);

            dcColumn = new DataColumn();
            dcColumn.ColumnName = "Count";
            dcColumn.DataType = System.Type.GetType("System.Int64");
            dcColumn.AllowDBNull = true;
            m_datasetUID.Tables[0].Columns.Add(dcColumn);

            dcColumn = new DataColumn();
            dcColumn.ColumnName = "Protocol";
            dcColumn.DataType = System.Type.GetType("System.String");
            dcColumn.AllowDBNull = true;
            m_datasetUID.Tables[0].Columns.Add(dcColumn);

            m_datasetUID.Tables[0].PrimaryKey = new DataColumn[] { m_datasetUID.Tables[0].Columns[0] };
            comboBox1.SelectedIndex = 0;
        }
        #endregion

        #region Button Controls
        private void btnInventoryClear_Click(object sender, EventArgs e)
        {
            dgInventory.DataSource = null;
            m_datasetUID.Tables[0].Rows.Clear();
        }

        private void btnBlockGetUID_Click(object sender, EventArgs e)
        {
            if (m_iHandle == -1)
            {
                MessageBox.Show("Please connect reader first");
                return;
            }
            int i;
            comboBlockUID.Text = "Found No Tag";
            m_datasetUID.Tables[0].Rows.Clear();
            comboBlockUID.Items.Clear();
            int TagCnt = Get_UID();

            if (TagCnt > 0)
            {
                btnBlockReadAll.Enabled = true;

                DataRow[] dr = m_datasetUID.Tables[0].Select("Protocol = '" + "ISO14443B" + "'");
                if (dr.Length > 0)
                {
                    QueryPerformanceCounter(ref m_lStartTime);    //start time
                    timer43B.Enabled = true;
                }
                btnBlockReadAll.Enabled = true;
                for (i = 0; i < TagCnt; i++)
                {
                    comboBlockUID.Items.Add(m_datasetUID.Tables[0].Rows[i]["Protocol"].ToString().PadRight(9, ' ') + ": " + m_datasetUID.Tables[0].Rows[i]["UID"].ToString());
                }
                Beep(100);
                LEDON(500);
                comboBlockUID.SelectedIndex = 0;
            }
            else
            {
                btnBlockReadAll.Enabled = false;
                btnBlockWrite.Enabled = false;
            }
        }

        private void btnBlockReadAll_Click(object sender, EventArgs e)
        {
            btnBlockReadAll.Enabled = false;
            timer43B.Enabled = false;

            if (!comboBlockUID.Text.StartsWith("ISO"))
            {
                MessageBox.Show("Please select UID first");

                return;
            }

            if (comboBlockUID.Text.StartsWith("ISO14443A"))
            {
                MessageBox.Show("Does not Support to Read and Write ISO14443A Tags' Memory Data.");
                btnBlockReadAll.Enabled = false;
                btnBlockWrite.Enabled = false;

                return;
            }

            string sUID;
            byte[] UID_Sel = null;
            if (comboBlockUID.Text.Substring(0, 8) == "ISO15693")
            {
                btnBlockReadAll.Enabled = true;
                btnBlockWrite.Enabled = false;

                sUID = comboBlockUID.Text.Substring(11, 16);

                UID_Sel = new byte[8];
                for (int j = 0; j < 8; j++)
                    UID_Sel[j] = byte.Parse(sUID.Substring(j * 2, 2), System.Globalization.NumberStyles.HexNumber);
                ShowISO15693BlockData(UID_Sel);
                btnBlockWrite.Enabled = true;
            }
            else if (comboBlockUID.Text.Substring(0, 9) == "ISO14443B")
            {
                btnBlockReadAll.Enabled = true;
                btnBlockWrite.Enabled = false;

                sUID = comboBlockUID.Text.Substring(11, 16);

                UID_Sel = new byte[8];
                for (int j = 0; j < 8; j++)
                    UID_Sel[j] = byte.Parse(sUID.Substring(j * 2, 2), System.Globalization.NumberStyles.HexNumber);
                ShowISO14443BBlockData(UID_Sel);
                QueryPerformanceCounter(ref m_lStartTime);
                timer43B.Enabled = true;

                // 2011-04-21 Adward
                btnBlockWrite.Enabled = true;
            }
        }

        private void btnBlockWrite_Click(object sender, EventArgs e)
        {
            btnBlockWrite.Enabled = false;

            if (!comboBlockUID.Text.StartsWith("ISO"))
            {
                MessageBox.Show("Please select UID first");
                btnBlockWrite.Enabled = true;

                return;
            }

            if (comboBlockUID.Text.StartsWith("ISO14443A"))
            {
                MessageBox.Show("Does not Support to Read and Write ISO14443A Tags' Memory Data.");
                btnBlockReadAll.Enabled = false;
                btnBlockWrite.Enabled = false;

                return;
            }

            timer43B.Enabled = false;
            string sUID = comboBlockUID.Text.Substring(11, 16);
            byte[] UID_Sel = System.Text.Encoding.ASCII.GetBytes(sUID);
            if (comboBlockUID.Text.Substring(0, 8) == "ISO15693")
            {
                UID_Sel = new byte[8];
                for (int j = 0; j < 8; j++)
                    UID_Sel[j] = byte.Parse(sUID.Substring(j * 2, 2), System.Globalization.NumberStyles.HexNumber);
                WriteISO15693BlockData(UID_Sel);
            }
            else if (comboBlockUID.Text.Substring(0, 9) == "ISO14443B")
            {
                UID_Sel = new byte[8];
                for (int j = 0; j < 8; j++)
                    UID_Sel[j] = byte.Parse(sUID.Substring(j * 2, 2), System.Globalization.NumberStyles.HexNumber);
                WriteISO14443BBlockData(UID_Sel);
                QueryPerformanceCounter(ref m_lStartTime);
                timer43B.Enabled = true;
            }
            btnBlockWrite.Enabled = true;
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            btnConnect.Enabled = false;
            int iType = 0;
            int iPort = int.Parse(comboConnectPort.Text);
            int iBaudRate = 115200;

            if (comboConnectType.Text == "USB")
            {
                iType = 4;
                m_iHandle = RFID_HF_API.RFID_HF_Connect(iType, iPort, iBaudRate); //for USB
            }
            else if (comboConnectType.Text == "UART")
            {
                iType = 1;
                iBaudRate = int.Parse(comboConnectBaudRate.Text);
                m_iHandle = RFID_HF_API.RFID_HF_Connect(iType, iPort, iBaudRate); //for Uart
            }

            if (m_iHandle >= 0)
            {
                int iModel = CheckModel();

                if (iModel >= 0)
                {
                    labelConStatus.Text = "Connected";
                    btnDisconnect.Enabled = true;
                    btnInventoryRead.Enabled = true;
                    btnInventoryStop.Enabled = true;

                    GetVersion(comboBox1.SelectedIndex);
                }
                else
                {
                    labelConStatus.Text = "Failed to Connect";
                    btnConnect.Enabled = true;
                    btnInventoryRead.Enabled = false;
                    btnInventoryStop.Enabled = false;
                }
            }
            else
            {
                labelConStatus.Text = "Failed to Connect";
                btnConnect.Enabled = true;
                btnInventoryRead.Enabled = false;
                btnInventoryStop.Enabled = false;

                m_iHandle = -1;
            }
        }

        private void btnDisconnect_Click(object sender, EventArgs e)
        {
            if (timer1.Enabled == true)
                MessageBox.Show("Please Stop Inventory !!");
            else
            {
                int Res = RFID_HF_API.RFID_HF_Disconnect(m_iHandle);
                m_iHandle = -1;
                labelConStatus.Text = "Disconnected";
                btnDisconnect.Enabled = false;
                btnConnect.Enabled = true;

                btnInventoryRead.Enabled = false;
                btnInventoryStop.Enabled = false;
            }
        }

        private void btnInventoryRead_Click(object sender, EventArgs e)
        {
            btnInventoryRead.Enabled = false;
            checkISO15693.Enabled = false;
            checkISO14443A.Enabled = false;
            checkISO14443B.Enabled = false;
            checkFeliCa.Enabled = false;
            btnReceive.Enabled = false;
            btnSend.Enabled = false;
            timer1.Enabled = true;
        }

        private void btnInventoryStop_Click(object sender, EventArgs e)
        {
            timer1.Enabled = false;
            btnInventoryRead.Enabled = true;
            checkISO15693.Enabled = true;
            checkISO14443A.Enabled = true;
            checkISO14443B.Enabled = true;
            checkFeliCa.Enabled = true;
            btnReceive.Enabled = true;
            btnSend.Enabled = true;
        }
        #endregion

        private int CheckModel()
        {
            int iModel = RFID_HF_API.RFID_GetReaderModel(m_iHandle);

            if (iModel == 0)
            {
                labelModel.Text = "1";

                checkISO14443A.Enabled = true;
                checkISO14443A.Checked = true;
                checkISO14443B.Enabled = true;
                checkISO14443B.Checked = true;
                checkISO15693.Enabled = true;
                checkISO15693.Checked = true;
                checkFeliCa.Enabled = true;
                checkFeliCa.Checked = true;
                btnSend.Enabled = true;
                btnReceive.Enabled = true;
            }
            else if (iModel == 1)
            {
                labelModel.Text = "2";

                checkISO14443A.Enabled = true;
                checkISO14443A.Checked = true;
                checkISO14443B.Enabled = true;
                checkISO14443B.Checked = true;
                checkISO15693.Enabled = true;
                checkISO15693.Checked = true;
                checkFeliCa.Enabled = true;
                checkFeliCa.Checked = true;
                btnSend.Enabled = false;
                btnReceive.Enabled = false; ;
            }
            else if (iModel == 2)
            {
                labelModel.Text = "3";

                checkISO14443A.Enabled = true;
                checkISO14443A.Checked = true;
                checkISO14443B.Enabled = false;
                checkISO14443B.Checked = false;
                checkISO15693.Enabled = true;
                checkISO15693.Checked = true;
                checkFeliCa.Enabled = false;
                checkFeliCa.Checked = false;
                btnSend.Enabled = false;
                btnReceive.Enabled = false; ;
            }
            return iModel;
        }

        private void GetVersion(int Mode)
        {
            byte[] data = new byte[40];
            string version = "";
            int len = RFID_HF_API.RFID_GetVersion(m_iHandle, data, Mode);
            if (len > 0)
            {
                if (Mode != 1)
                {
                    System.Text.ASCIIEncoding asciiEncoding = new System.Text.ASCIIEncoding();
                    version = asciiEncoding.GetString(data);
                }
                else
                {
                    version = data[0].ToString() + "." + data[1].ToString();
                    version += " " + data[3].ToString().PadLeft(2, '0') + "/" + data[4].ToString().PadLeft(2, '0') + "/20" + data[5].ToString().PadLeft(2, '0');
                    version += " " + data[6].ToString().PadLeft(2, '0') + ":" + data[7].ToString().PadLeft(2, '0') + ":" + data[8].ToString().PadLeft(2, '0');
                }
            }
            this.lbVer.Text = version;
        }

        #region Timer Controls
        private void timer1_Tick(object sender, EventArgs e)
        {
            int iTagCount = Get_UID();
            if (iTagCount > 0)
            {
                Beep(10);
                LEDON(10);
                dgInventory.DataSource = m_datasetUID.Tables[0];
            }
        }
        #endregion


        #region Function Controls
        private void CreatTable(int BytePerBlk, string Protocol)
        {
            m_datasetBlockData = new DataSet();
            m_datasetBlockData.Tables.Add("Blk");

            DataColumn dcColumn;
            dcColumn = new DataColumn();
            dcColumn.ColumnName = "Blk";
            dcColumn.DataType = System.Type.GetType("System.Int16");
            dcColumn.AllowDBNull = true;
            m_datasetBlockData.Tables["Blk"].Columns.Add(dcColumn);

            for (int i = 0; i < BytePerBlk; i++)
            {
                dcColumn = new DataColumn();
                dcColumn.ColumnName = "Data" + i.ToString();
                dcColumn.DataType = System.Type.GetType("System.String");
                dcColumn.AllowDBNull = true;
                m_datasetBlockData.Tables["Blk"].Columns.Add(dcColumn);
            }

            if (Protocol == "ISO15693")
            {
                dcColumn = new DataColumn();
                dcColumn.ColumnName = "Status";
                dcColumn.DataType = System.Type.GetType("System.String");
                dcColumn.AllowDBNull = true;
                m_datasetBlockData.Tables["Blk"].Columns.Add(dcColumn);
            }

            m_datasetBlockData.Tables["Blk"].PrimaryKey = new DataColumn[] { m_datasetBlockData.Tables["Blk"].Columns[0] };
        }

        private bool Filter(string uid)
        {
            try
            {
                bool res = true;

                DataRow[] dr = m_datasetUID.Tables[0].Select("UID = '" + uid + "'");
                if (dr.Length > 0)
                {
                    long readcount = long.Parse(dr[0]["count"].ToString());
                    readcount++;
                    dr[0]["count"] = readcount.ToString();
                    res = false;   //if epc exist,then break
                    m_datasetUID.Tables[0].AcceptChanges();
                }
                return res;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        private int Get_UID()
        {
            string sUID = "";
            uint TotalCnt = 0;
            byte TagNo = 0;
            int i, j, tagcount, Res;
            byte[] uid = new byte[160];
            byte[] UIDLen = new byte[8];
            byte[] cid = new byte[8];

            if (checkISO15693.Checked)
            {
                TagNo = (byte)RFID_HF_SDK.RFID_HF_API.RFID_15693_ReadMultiUID(m_iHandle, 0xCC, 0, uid);
                //TagNo = (byte)RFID_HF_API.RFID_15693_ReadUID(m_iHandle, 0x000C, 0, uid);

                TotalCnt += TagNo;
                for (int count = 0; count < TagNo; count++)
                {
                    string buf = "";
                    for (i = 0; i < 8; i++)
                        buf += uid[count * 8 + i].ToString("X").PadLeft(2, '0');
                    sUID = buf.Replace("-", "");
                    if (Filter(sUID))
                    {
                        DataRow drNew = m_datasetUID.Tables[0].NewRow();
                        drNew["UID"] = sUID;
                        drNew["Protocol"] = "ISO15693";
                        drNew["Count"] = "1";
                        m_datasetUID.Tables[0].Rows.Add(drNew);
                    }
                }
            }

            if (checkISO14443A.Checked)
            {
                Res = RFID_HF_API.RFID_14443A_ReadUID(m_iHandle, ref TagNo, UIDLen, uid);
                if (Res == 0)
                {
                    TotalCnt += TagNo;
                    for (i = 0; i < TagNo; i++)
                    {
                        sUID = "";
                        if (UIDLen[i] > 0)
                        {
                            for (j = 0; j < UIDLen[i]; j++)
                            {
                                sUID += uid[i * 10 + (UIDLen[i] - 1) - j].ToString("X").PadLeft(2, '0');
                            }
                            if (Filter(sUID))
                            {
                                DataRow drNew = m_datasetUID.Tables[0].NewRow();
                                drNew["UID"] = sUID;
                                drNew["Protocol"] = "ISO14443A";
                                drNew["Count"] = "1";
                                m_datasetUID.Tables[0].Rows.Add(drNew);
                            }
                        }
                    }
                }
            }

            if (checkISO14443B.Checked)
            {
                
                Res = RFID_HF_API.RFID_14443B_ReadUID(m_iHandle, ref TagNo, uid);
                if (Res == 0)
                {
                    TotalCnt += TagNo;
                    for (i = 0; i < TagNo; i++)
                    {
                        sUID = "";
                        for (j = 0; j < 8; j++)
                        {
                            sUID += uid[i * 8 + j].ToString("X").PadLeft(2, '0');
                        }
                        if (Filter(sUID))
                        {
                            DataRow drNew = m_datasetUID.Tables[0].NewRow();
                            drNew["UID"] = sUID;
                            drNew["Protocol"] = "ISO14443B";
                            drNew["Count"] = "1";
                            m_datasetUID.Tables[0].Rows.Add(drNew);
                        }
                    }
                }
            }
            return (int)TotalCnt;
        }


        private void ShowISO15693BlockData(byte[] UID_Sel)
        {
            int Res, BytePerBlk = 0, BlkSize = 0, i, j;
            byte AFI = 0, DSFID = 0, Flag = 0;
            byte[] Rpt = null;
            byte BlkSts = 0;
            Res = RFID_HF_API.RFID_15693_GetSysInfo(m_iHandle, UID_Sel, ref BytePerBlk, ref BlkSize, ref AFI, ref DSFID, ref Flag);
            if (Res != 0)
            {
                if (textBlockCount.Text != "" && textBlockSize.Text != "")
                {
                    BytePerBlk = byte.Parse(textBlockSize.Text);
                    BlkSize = byte.Parse(textBlockCount.Text);
                }
                else
                {
                    MessageBox.Show("No Tag Found or Not Support Get System Info. Please Input Block Information");
                    return;
                }
            }
            textBlockSize.Text = BytePerBlk.ToString();
            textBlockCount.Text = BlkSize.ToString();
            CreatTable(BytePerBlk, "ISO15693");
            Rpt = new byte[BytePerBlk];
            for (i = 0; i < BlkSize; i++)
            {
                Res = RFID_HF_API.RFID_15693_ReadOneBlock(m_iHandle, UID_Sel, BytePerBlk, i, Rpt, ref BlkSts);
                if (Res != 0)
                {
                    MessageBox.Show("Read Block Fail");
                    return;
                }
                DataRow drNew = m_datasetBlockData.Tables[0].NewRow();
                drNew[0] = i.ToString();
                for (j = 0; j < BytePerBlk; j++)
                    drNew[j + 1] = Rpt[j].ToString("X");
                drNew[BytePerBlk + 1] = BlkSts;
                m_datasetBlockData.Tables[0].Rows.Add(drNew);

            }
            dgBlk.DataSource = m_datasetBlockData.Tables["Blk"];
            dgBlk.Columns[0].ReadOnly = true;
            dgBlk.Columns[BytePerBlk + 1].ReadOnly = true;
            Beep(100);
            LEDON(500);
        }


        private void ShowISO14443BBlockData(byte[] UID_Sel)
        {
            int Res, ReadCnt = 0, j;
            byte Addr = 0;
            CreatTable(4, "ISO14443B");
            byte[] Rpt = new byte[4];
            int iBlocks = 0;
            int i;

            for(i = 0; i<128; i++) {
                Res = RFID_HF_API.RFID_14443B_ReadBlock(m_iHandle, UID_Sel, Addr, Rpt);
                
                if (Res != 0)
                {
                    MessageBox.Show("Read Block Fail");
                    break;
                }

                DataRow drNew = m_datasetBlockData.Tables[0].NewRow();
                drNew[0] = Addr.ToString();
                for (j = 0; j < 4; j++)
                    drNew[j + 1] = Rpt[j].ToString("X");

                m_datasetBlockData.Tables[0].Rows.Add(drNew);

                Addr++;
                iBlocks++;
                ReadCnt++;
            }

            Addr = 255;
            Res = RFID_HF_API.RFID_14443B_ReadBlock(m_iHandle, UID_Sel, Addr, Rpt);
            if (Res == 0)
            {
                DataRow drNew = m_datasetBlockData.Tables[0].NewRow();
                drNew[0] = Addr.ToString();
                for (j = 0; j < 4; j++)
                    drNew[j + 1] = Rpt[j].ToString("X");

                m_datasetBlockData.Tables[0].Rows.Add(drNew);
            }

            textBlockCount.Text = iBlocks.ToString();
            textBlockSize.Text = "4";
            dgBlk.DataSource = m_datasetBlockData.Tables["Blk"];
            Beep(100);
            LEDON(500);
        }


        void Beep(int iTime)
        {
            if (checkBeep.Checked)
            {
                RFID_HF_API.RFID_SetGPIO(m_iHandle, IO_BEEP, true);
                timer_Beep.Enabled = true;
                timer_Beep.Interval = iTime;
            }
        }

        void LEDON(int iTime)
        {
            if (checkLed.Checked)
            {
                RFID_HF_API.RFID_SetGPIO(m_iHandle, IO_LED, true);
                timer_LED.Enabled = true;
                timer_LED.Interval = iTime;
            }
        }


        private void WriteISO15693BlockData(byte[] UID_Sel)
        {
            int WriStart = 0, i, j, Res = 0, PwdLen;
            int BytePerBlk = m_datasetBlockData.Tables[0].Columns.Count - 2;
            int WriEnd = m_datasetBlockData.Tables[0].Rows.Count - 1;
            byte[] WriData = new byte[BytePerBlk];
            byte[] PWD = null;
            if (textBlockStart.Text != "" && textBlockEnd.Text != "")
            {
                WriStart = int.Parse(textBlockStart.Text);
                WriEnd = int.Parse(textBlockEnd.Text);
            }
            for (i = WriStart; i <= WriEnd; i++)
            {
                for (j = 0; j < BytePerBlk; j++)
                    WriData[j] = byte.Parse(m_datasetBlockData.Tables[0].Rows[i][j + 1].ToString(), System.Globalization.NumberStyles.HexNumber);

                if (radioNormal.Checked)
                {
                    Res = RFID_HF_API.RFID_15693_WriteOneBlock(m_iHandle, UID_Sel, BytePerBlk, i, WriData, 0);
                }
                else if (radioOption.Checked)
                {
                    Res = RFID_HF_API.RFID_15693_WriteOneBlock(m_iHandle, UID_Sel, BytePerBlk, i, WriData, 1);
                }
                else if (radioFujitsu.Checked)
                {
                }
                else
                {
                    if (rdo32.Checked)
                        PwdLen = 4;
                    else
                        PwdLen = 8;
                    PWD = new byte[PwdLen];
                    for (j = 0; j < PwdLen; j++)
                        PWD[j] = byte.Parse(textPassword.Text.Substring(j * 2, 2), System.Globalization.NumberStyles.HexNumber);

                    Res = RFID_HF_API.RFID_15693_SecureWriteBlock(m_iHandle, UID_Sel, BytePerBlk, i, PWD, PwdLen, WriData);
                }

                if (Res != 0)
                {
                    MessageBox.Show("Write Block " + i.ToString() + " Fail");
                    return;
                }
            }
            Beep(100);
            LEDON(500);
        }
        #endregion

        private void comboConnectType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboConnectType.SelectedIndex == 0)
                comboConnectBaudRate.Enabled = false;
            else if (comboConnectType.SelectedIndex == 1)
            {
                comboConnectBaudRate.SelectedIndex = 4;
                comboConnectBaudRate.Enabled = true;
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem.ToString() == "About ClarIDy HF Demo")
            {
                AboutBox1 about = new AboutBox1();
                about.ShowDialog();
            }
            else
                GetVersion(comboBox1.SelectedIndex);
        }

        private void WriteISO14443BBlockData(byte[] UID_Sel)
        {
            int j, wRes, rRes, Error = 0, WriteCnt = 0;
            byte i;
            byte WriStart = 0;
            int BytePerBlk = m_datasetBlockData.Tables[0].Columns.Count - 1;
            byte WriEnd = Convert.ToByte(m_datasetBlockData.Tables[0].Rows.Count - 1);
            byte[] WriData = new byte[BytePerBlk];
            byte[] ReadData = new byte[BytePerBlk];

            if (textBlockStart.Text != "" && textBlockEnd.Text != "")
            {
                WriStart = byte.Parse(textBlockStart.Text);
                WriEnd = byte.Parse(textBlockEnd.Text);
            }

            for (i = WriStart; i <= WriEnd; i++)
            {
                for (j = 0; j < BytePerBlk; j++)
                    WriData[j] = byte.Parse(m_datasetBlockData.Tables[0].Rows[(int)i][j + 1].ToString(), System.Globalization.NumberStyles.HexNumber);

                j = 0;

                wRes = RFID_HF_API.RFID_14443B_WriteBlock(m_iHandle, UID_Sel, i, WriData);

                if (wRes != 0)
                {
                    MessageBox.Show("Write " + i.ToString() + " Block Fail");
                    break;
                }
            }
            
            Beep(100);
            LEDON(500);
        }

        private void btnFileBrowserS_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                txtSendFilename.Text = openFileDialog1.FileName;
                //                string sFilename = openFileDialog1.FileName;
            }
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            try
            {
                labelFileMessage.Text = "";

                string txFile = txtSendFilename.Text;
                byte[] ucpFilenameBuf = System.Text.ASCIIEncoding.ASCII.GetBytes(txFile);
                RFID_HF_API.m3xTxCB txPCB = new RFID_HF_API.m3xTxCB(TxStatus);
                int res = 0;
                res = RFID_HF_API.RFID_M3XSendFile(m_iHandle, ucpFilenameBuf, txPCB);
                if (res == 0)
                {
                    labelFileMessage.Text = "Send Success";
                    Beep(100);
                }
                else
                    labelFileMessage.Text = "Send Fail, Error Code= " + res.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnFileBrowserR_Click(object sender, EventArgs e)
        {
            if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
            {
                txtReceivePath.Text = folderBrowserDialog1.SelectedPath + "\\";
            }
        }

        private void btnReceive_Click(object sender, EventArgs e)
        {
            try
            {
                labelFileMessage.Text = "";
                string rxPath = txtReceivePath.Text;
                byte[] ucpFilePathBuf = System.Text.ASCIIEncoding.ASCII.GetBytes(rxPath);
                RFID_HF_API.m3xRxCB rxPCB = new RFID_HF_API.m3xRxCB(RxStatus);
                int res = RFID_HF_API.RFID_M3XReceiveFile(m_iHandle, ucpFilePathBuf, rxPCB);
                if (res == 0)
                {
                    Beep(100);
                    labelFileMessage.Text = "Receive Success";
                }
                else
                    labelFileMessage.Text = "Receive Fail, Error Code= " + res.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        private void RxStatus(UInt32 uiByteCount, UInt32 uiFileSize, string sFilename)
        {
            barRx.Maximum = (int)uiFileSize;
            barRx.Value = (int)uiByteCount;
            txtReceiveFilename.Text = sFilename;
            int iLen = sFilename.Length;
            string sType = sFilename.Substring(iLen - 3, 3);
            if (sType.Contains("jpg") || sType.Contains("JPG"))
            {
                pictureBoxNFC.ImageLocation = sFilename;
            }
        }


        private void TxStatus(UInt32 uiByteCount, UInt32 uiFileSize)
        {
            barTx.Maximum = (int)uiFileSize;
            barTx.Value = (int)uiByteCount;
        }
    }
}

