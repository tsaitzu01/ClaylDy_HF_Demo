﻿// File: HF_RFID_SDK.cs
//
// Copyright (c) 2010 ClarIDy Solutions, Inc.
// All rights reserved.
// 
// Author: Horng-Ji Chen
// 
// Descriptions: HF RFID SDK defines the control functions of the ClarIDy HF RFID
//               and NFC protocols. The software develop kit (SDK) provides the
//               application program interface (API)  of the above air protocols.
//               The CSharp interface of the ClarIDy HF RFID API provides the
//				 following protocols:
//				 ISO-15693,
//				 ISO-14443A and ISO-1443B,
//				 FeLiCa, and
//				 ISO-18904.
//
// RFID_HF_SDK
// Revision: A.4
//
// History:
// 2008-07-21: Rev. A.1 by Horng-Ji Chen
// Created the basic functions for the ClarIDy HF RFID API functions.
//
// 2008-08-15: Rev. A.2 by Horng-Ji Chen
// Added more functions of  the ClarIDy HF RFID API.
//
// 2008-11-03: Rev. A.3 by Horng-Ji Chen
// Added RFID 15693 ReadMultiUID function.
//
// 2010-11-30: Rev. A.4 by Horng-Ji Chen
// Upgrade firmware version 1.7 compatibility for Windows 7
// Obsolete functions:
// RFID_15693_ReadOneBlockSel,
// RFID_15693_ReadOID,
// RFID_15693_ReadKey,
// RFID_15693_WriteKey,
// RFID_15693_LockKey,
// RFID_15693_FastReadBlock,
// RFID_15693_FastReadUID,
// RFID_15693_FastWriteOneBlock
// Modified functions:
// RFID_GetReaderModel,
// RFID_15693_SecureReadBlock,
// RFID_15693_SecureWriteBlock,
// RFID_15693_WritePWD,
// RFID_14443B_ReadUID_Std
// Additional functions:
// RFID_15693_SecureReadBlockEx,
// RFID_15693_SecureWriteBlockEx,
// RFID_15693_WritePWDEx,
// RFID_14443B_ReadUID_StdEx
//

using System;
using System.Runtime.InteropServices;

namespace RFID_HF_SDK
{
    public class RFID_HF_API
    {
        // HF Reader Connection Control Function
        [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_HF_Connect")]
        public static extern int RFID_HF_Connect(int iType, int iPort, int iBaudrate);

        [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_HF_Disconnect")]
        public static extern int RFID_HF_Disconnect(int iHandle);

        // Generic Functions
        [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_GetVersion")]
        public static extern int RFID_GetVersion(int iHandle, byte[] ucpData, int Mode);

        [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_GetReaderModel")]   // ***
        public static extern int RFID_GetReaderModel(int iHandle);

        [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_ReadGValue")]
        public static extern int RFID_ReadGValue(int iHandle, UInt16 usIndex, byte[] ucpData);

        [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_WriteGValue")]
        public static extern int RFID_WriteGValue(int iHandle, UInt16 usIndex, byte ucDataLength, byte[] ucpData);

        [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_ReadXData")]   // ***
        public static extern int RFID_ReadXData(int iHandle, UInt16 usAddress, byte ucLength, byte[] ucpData);

        [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_WriteXData")]  // ***
        public static extern int RFID_WriteXData(int iHandle, UInt16 usAddress, byte ucLength, byte[] ucpData);


        // ISO 15693 Control Functions
        [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_15693_ReadUID")]
        public static extern int RFID_15693_ReadUID(int iHandle, int iAFIFlag, byte ucAFI, byte[] ucpUID);

        [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_15693_ReadMultiUID")]
        public static extern int RFID_15693_ReadMultiUID(int iHandle, int iAFIFlag, byte ucAFI, byte[] ucpUID);

        [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_15693_ReadOneBlock")]  // ***
        public static extern int RFID_15693_ReadOneBlock(int iHandle, byte[] ucpUID, int iBytePerBlock, int iBlockNum, byte[] ucpReport, ref byte ucpBlockStatus);

        [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_15693_WriteOneBlock")]
        public static extern int RFID_15693_WriteOneBlock(int iHandle, byte[] ucpUID, int iBytePerBlock, int iBlockNum, byte[] ucpReport, byte ucOption);

        [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_15693_StayQuiet")]
        public static extern int RFID_15693_StayQuiet(int iHandle, byte[] ucpUID);

        [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_15693_ResetToReady")]
        public static extern int RFID_15693_ResetToReady(int iHandle, byte[] ucpUID);

        [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_15693_Select")]
        public static extern int RFID_15693_Select(int iHandle, byte[] ucpUID);

        [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_15693_GetSysInfo")]    // ***
        public static extern int RFID_15693_GetSysInfo(int iHandle, byte[] ucpUID, ref int ipBytePerBlock, ref int ipBlockSize, ref byte ucpAFI, ref byte ucpDSFID, ref byte ucpFlag);

        [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_15693_WriteAFI")]
        public static extern int RFID_15693_WriteAFI(int iHandle, byte[] ucpUID, byte ucAFI, byte ucOption);

        [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_15693_WriteDSF")]
        public static extern int RFID_15693_WriteDSF(int iHandle, byte[] ucpUID, byte ucDSFID, byte ucOption);

        [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_15693_LockAFI")]
        public static extern int RFID_15693_LockAFI(int iHandle, byte[] ucpUID, byte ucOption);

        [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_15693_LockDSF")]
        public static extern int RFID_15693_LockDSF(int iHandle, byte[] ucpUID, byte ucOption);

        [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_15693_LockBlock")]
        public static extern int RFID_15693_LockBlock(int iHandle, byte[] ucpUID, int iBlockNum, byte ucOption);

        [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_15693_BlockLockInfo")]
        public static extern int RFID_15693_BlockLockInfo(int iHandle, byte[] ucpUID, int iStartBlock, int iBlockNum, ref byte[] ucpBlockLockInfo);

        [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_15693_ReadMultiBlock")]
        public static extern int RFID_15693_ReadMultiBlock(int iHandle, byte[] ucpUID, int iStartBlock, int iBlockNum, byte[] ucpBlockData, byte ucOption);

        [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_15693_ReadEAS")]
        public static extern int RFID_15693_ReadEAS(int iHandle, byte[] ucpUID, ref byte ucpEAS);

        [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_15693_WriteEAS")]
        public static extern int RFID_15693_WriteEAS(int iHandle, byte[] ucpUID, byte ucEAS);

        [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_15693_LockEAS")]
        public static extern int RFID_15693_LockEAS(int iHandle, byte[] ucpUID);

        [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_15693_SecureReadBlock")]
        public static extern int RFID_15693_SecureReadBlock(int iHandle, byte[] ucpUID, int iBytePerBlock, int iBlockNum, byte[] ucpPWD, int iPWDLength, byte[] ucpReport, ref byte ucpBlockStatus);

        [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_15693_SecureReadBlockEx")]
        public static extern int RFID_15693_SecureReadBlockEx(int iHandle, byte[] ucpUID, int iBytePerBlock, int iBlockNum, byte[] ucpPWD, byte[] ucpReport);

        [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_15693_SecureWriteBlock")]
        public static extern int RFID_15693_SecureWriteBlock(int iHandle, byte[] ucpUID, int iBytePerBlock, int iBlockNum, byte[] ucpPWD, int iPWDLength, byte[] ucpData);

        [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_15693_SecureWriteBlockEx")]
        public static extern int RFID_15693_SecureWriteBlockEx(int iHandle, byte[] ucpUID, int iBytePerBlock, int iBlockNum, byte[] ucpPWD, byte[] ucpData);

        // [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_15693_ReadOID")]
        // public static extern int RFID_15693_ReadOID(int iHandle, byte[] ucpUID, byte[] ucpReport);

        [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_15693_WritePWD")]
        public static extern int RFID_15693_WritePWD(int iHandle, byte[] ucpUID, int iBytePerBlock, int iPWDLength, byte[] ucpData);

        [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_15693_WritePWDEx")]
        public static extern int RFID_15693_WritePWDEx(int iHandle, byte[] ucpUID, byte[] ucpData);

        [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_15693_LockPWD")]
        public static extern int RFID_15693_LockPWD(int iHandle, byte[] ucpUID);

        // [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_15693_ReadKey")]
        // public static extern int RFID_15693_ReadKey(int iHandle, byte[] ucpUID, byte[] ucpReport);

        // [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_15693_WriteKey")]
        // public static extern int RFID_15693_WriteKey(int iHandle, byte[] ucpUID, int iBytePerBlock, byte[] ucpData);

        // [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_15693_LockKey")]
        // public static extern int RFID_15693_LockKey(int iHandle, byte[] ucpUID);

        // [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_15693_FastReadBlock")]
        // public static extern int RFID_15693_FastReadBlock(int iHandle, byte[] ucpUID, int iBytePerBlock, int iBlockNum, byte[] ucpReport, ref byte ucpBlockStatus);

        // [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_15693_FastReadUID")]
        // public static extern int RFID_15693_FastReadUID(int iHandle, int iAFIFlag, byte ucAFI, byte[] ucpUID);

        // [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_15693_FastWriteOneBlock")]
        // public static extern int RFID_15693_FastWriteOneBlock(int iHandle, byte[] ucpUID, int iBytePerBlock, int iBlockNum, byte[] ucpReport, byte ucOption);


        // ISO 14443 Control Functions
        [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_14443A_ReadUID")]
        public static extern int RFID_14443A_ReadUID(int iHandle, ref byte ucpTagNum, byte[] UIDLength, byte[] ucpUID);

        [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_14443B_ReadUID")]
        public static extern int RFID_14443B_ReadUID(int iHandle, ref byte ucpTagNum, byte[] ucpUID);

        //ATMEL Tag
        [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_14443B_ReadUID_Std")]
        public static extern int RFID_14443B_ReadUID_Std(int iHandle, ref byte ucpTagNum, byte[] ucpUID, byte[] ucpCID, byte ucOption);

        [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_14443B_ReadUID_StdEx")]
        public static extern int RFID_14443B_ReadUID_StdEx(int iHandle, ref byte ucpTagNum, byte[] ucpUID, byte[] ucpCID);

        [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_14443B_ReadBlock")]
        public static extern int RFID_14443B_ReadBlock(int iHandle, byte[] ucpUID, byte ucAddress, byte[] ucpData);

        [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_14443B_WriteBlock")]
        public static extern int RFID_14443B_WriteBlock(int iHandle, byte[] ucpUID, byte ucAddress, byte[] ucpData);

        [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_14443B_Attribute")]
        public static extern int RFID_14443B_Attribute(int iHandle, byte ucCID, byte[] ucpPUPI, byte[] ucpData);

        [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_14443B_Completion")]
        public static extern int RFID_14443B_Completion(int iHandle, byte[] ucpUID);

        [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_AT88RF020_Read")]
        public static extern int RFID_AT88RF020_Read(int iHandle, byte ucCID, byte ucAddress, byte[] ucpData);

        [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_AT88RF020_Write")]
        public static extern int RFID_AT88RF020_Write(int iHandle, byte ucCID, byte ucAddress, byte[] ucpWriteData, byte[] ucpData);

        [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_AT88RF020_CheckPWD")]
        public static extern int RFID_AT88RF020_CheckPWD(int iHandle, byte ucCID, byte[] ucpPWD, byte[] ucpData);

        [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_AT88RF020_Deselect")]
        public static extern int RFID_AT88RF020_Deselect(int iHandle, byte ucCID, byte[] ucpData);

        [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_AT88RF020_Lock")]
        public static extern int RFID_AT88RF020_Lock(int iHandle, byte ucCID, byte[] ucpLockData, byte[] ucpData);


        [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_AT88RF020_Count")]
        public static extern int RFID_AT88RF020_Count(int iHandle, byte ucCID, byte[] ucpCountData, byte[] ucpData);

        [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_UltraLight_ReadBlocks")]
        public static extern int RFID_UltraLight_ReadBlocks(int iHandle, byte ucAddress, byte[] ucpData);

        [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_UltraLight_WriteBlock")]
        public static extern int RFID_UltraLight_WriteBlock(int iHandle, byte ucAddress, byte[] ucpWriteData, byte[] ucpData);

        [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_TOPAZ_WakeUp")]
        public static extern int RFID_TOPAZ_WakeUp(int iHandle, byte[] ucpData);

        [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_TOPAZ_ReadUID")]
        public static extern int RFID_TOPAZ_ReadUID(int iHandle, byte[] ucpData);

        [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_TOPAZ_ReadByte")]
        public static extern int RFID_TOPAZ_ReadByte(int iHandle, byte ucAddress, byte[] ucpUID, byte[] ucpData);

        [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_TOPAZ_WriteByte")]
        public static extern int RFID_TOPAZ_WriteByte(int iHandle, byte ucAddress, byte ucData, byte[] ucpUID, byte[] ucpData);



        // FeliCa Control Functions
        [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_FeliCa_ReadUID")]
        public static extern int RFID_FeliCa_ReadUID(int iHandle, byte[] ucpUID);

        // File Transfer Functions
        // public delegate 
        public delegate void m3xTxCB(UInt32 uiByteCount, UInt32 uiFileSize);
        public delegate void m3xRxCB(UInt32 uiByteCount, UInt32 uiFileSize, string ucpFilename);

        [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_M3XSendFile")]
        public static extern int RFID_M3XSendFile(int handle, byte[] file_name, m3xTxCB pCB);

        [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_M3XReceiveFile")]
        public static extern int RFID_M3XReceiveFile(int handle, byte[] file_path, m3xRxCB pCB);

        [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_ErrorMessage")]
        public static extern char[] RFID_ErrorMessage(int iCode);

        //Secure
        [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_MD5Hash")]
        public static extern void RFID_MD5Hash(byte[] input, int inputlen, byte[] output);

        [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_RSAGenKeyPair")]
        public static extern int RFID_RSAGenKeyPair(int size, byte[] keyfilename);

        [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_RSASetKey")]
        public static extern int RFID_RSASetKey(int mode, int size, byte[] keyfilename);

        [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_RSAEncrypt")]
        public static extern int RFID_RSAEncrypt(int mode, int inputlen, byte[] input, byte[] output);

        [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_RSADecrypt")]
        public static extern int RFID_RSADecrypt(int mode, int[] outputlen, byte[] input, byte[] output);

        [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_AESSetKey")]
        public static extern void RFID_AESSetKey(int mode, byte[] key, int keysize);

        [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_AESCrypt")]
        public static extern void RFID_AESCrypt(int mode, byte[] input, byte[] output);

        [DllImport("RFID_HF_SDK.dll", EntryPoint = "RFID_SetGPIO")]
        public static extern int RFID_SetGPIO(int handle, byte ucIO, bool bEnable);

    }
}
