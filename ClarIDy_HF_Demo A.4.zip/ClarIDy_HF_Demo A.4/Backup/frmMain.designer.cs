﻿namespace ClarIDy_HF_Demo
{
    partial class frmMain
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改這個方法的內容。
        ///
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panelMain = new System.Windows.Forms.Panel();
            this.checkLed = new System.Windows.Forms.CheckBox();
            this.checkBeep = new System.Windows.Forms.CheckBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.lbVer = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.checkISO15693 = new System.Windows.Forms.CheckBox();
            this.checkFeliCa = new System.Windows.Forms.CheckBox();
            this.checkISO14443A = new System.Windows.Forms.CheckBox();
            this.checkISO14443B = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.labelModel = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.comboConnectBaudRate = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.btnConnect = new System.Windows.Forms.Button();
            this.comboConnectType = new System.Windows.Forms.ComboBox();
            this.labelConStatus = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btnDisconnect = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.comboConnectPort = new System.Windows.Forms.ComboBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.tabMain = new System.Windows.Forms.TabControl();
            this.tabPageInventory = new System.Windows.Forms.TabPage();
            this.dgInventory = new System.Windows.Forms.DataGridView();
            this.btnInventoryStop = new System.Windows.Forms.Button();
            this.btnInventoryClear = new System.Windows.Forms.Button();
            this.btnInventoryRead = new System.Windows.Forms.Button();
            this.tabPageBlockData = new System.Windows.Forms.TabPage();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label15 = new System.Windows.Forms.Label();
            this.rdo64 = new System.Windows.Forms.RadioButton();
            this.textPassword = new System.Windows.Forms.TextBox();
            this.rdo32 = new System.Windows.Forms.RadioButton();
            this.label14 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.radioSecure = new System.Windows.Forms.RadioButton();
            this.radioFujitsu = new System.Windows.Forms.RadioButton();
            this.radioOption = new System.Windows.Forms.RadioButton();
            this.radioNormal = new System.Windows.Forms.RadioButton();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.textBlockEnd = new System.Windows.Forms.TextBox();
            this.textBlockStart = new System.Windows.Forms.TextBox();
            this.btnBlockWrite = new System.Windows.Forms.Button();
            this.textBlockSize = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.textBlockCount = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.btnBlockGetUID = new System.Windows.Forms.Button();
            this.comboBlockUID = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.btnBlockReadAll = new System.Windows.Forms.Button();
            this.dgBlk = new System.Windows.Forms.DataGridView();
            this.tabPageNFC = new System.Windows.Forms.TabPage();
            this.labelFileMessage = new System.Windows.Forms.Label();
            this.pictureBoxNFC = new System.Windows.Forms.PictureBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.btnFileBrowserR = new System.Windows.Forms.Button();
            this.barRx = new System.Windows.Forms.ProgressBar();
            this.txtReceiveFilename = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txtReceivePath = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.btnReceive = new System.Windows.Forms.Button();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.btnFileBrowserS = new System.Windows.Forms.Button();
            this.barTx = new System.Windows.Forms.ProgressBar();
            this.txtSendFilename = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.btnSend = new System.Windows.Forms.Button();
            this.timer43B = new System.Windows.Forms.Timer(this.components);
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.timer_Beep = new System.Windows.Forms.Timer(this.components);
            this.timer_LED = new System.Windows.Forms.Timer(this.components);
            this.panelMain.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tabMain.SuspendLayout();
            this.tabPageInventory.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgInventory)).BeginInit();
            this.tabPageBlockData.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgBlk)).BeginInit();
            this.tabPageNFC.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxNFC)).BeginInit();
            this.groupBox7.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelMain
            // 
            this.panelMain.Controls.Add(this.checkLed);
            this.panelMain.Controls.Add(this.checkBeep);
            this.panelMain.Controls.Add(this.groupBox5);
            this.panelMain.Controls.Add(this.groupBox2);
            this.panelMain.Controls.Add(this.groupBox1);
            this.panelMain.Controls.Add(this.pictureBox1);
            this.panelMain.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelMain.Location = new System.Drawing.Point(0, 0);
            this.panelMain.Name = "panelMain";
            this.panelMain.Size = new System.Drawing.Size(195, 446);
            this.panelMain.TabIndex = 1;
            // 
            // checkLed
            // 
            this.checkLed.AutoSize = true;
            this.checkLed.Checked = true;
            this.checkLed.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkLed.Location = new System.Drawing.Point(116, 294);
            this.checkLed.Name = "checkLed";
            this.checkLed.Size = new System.Drawing.Size(46, 16);
            this.checkLed.TabIndex = 21;
            this.checkLed.Text = "LED";
            this.checkLed.UseVisualStyleBackColor = true;
            // 
            // checkBeep
            // 
            this.checkBeep.AutoSize = true;
            this.checkBeep.Checked = true;
            this.checkBeep.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBeep.Location = new System.Drawing.Point(116, 273);
            this.checkBeep.Name = "checkBeep";
            this.checkBeep.Size = new System.Drawing.Size(48, 16);
            this.checkBeep.TabIndex = 21;
            this.checkBeep.Text = "Beep";
            this.checkBeep.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.comboBox1);
            this.groupBox5.Controls.Add(this.lbVer);
            this.groupBox5.Location = new System.Drawing.Point(12, 367);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(174, 77);
            this.groupBox5.TabIndex = 20;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Version";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "RFID HF SDK",
            "Firmware",
            "ISO 15603",
            "ISO 14443",
            "P2P",
            "Secure",
            "About ClarIDy HF Demo"});
            this.comboBox1.Location = new System.Drawing.Point(13, 21);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 20);
            this.comboBox1.TabIndex = 2;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // lbVer
            // 
            this.lbVer.AutoSize = true;
            this.lbVer.Location = new System.Drawing.Point(14, 54);
            this.lbVer.Name = "lbVer";
            this.lbVer.Size = new System.Drawing.Size(0, 12);
            this.lbVer.TabIndex = 1;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.checkISO15693);
            this.groupBox2.Controls.Add(this.checkFeliCa);
            this.groupBox2.Controls.Add(this.checkISO14443A);
            this.groupBox2.Controls.Add(this.checkISO14443B);
            this.groupBox2.Location = new System.Drawing.Point(10, 256);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(95, 105);
            this.groupBox2.TabIndex = 19;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Tag Type";
            // 
            // checkISO15693
            // 
            this.checkISO15693.AutoSize = true;
            this.checkISO15693.Checked = true;
            this.checkISO15693.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkISO15693.Location = new System.Drawing.Point(8, 17);
            this.checkISO15693.Name = "checkISO15693";
            this.checkISO15693.Size = new System.Drawing.Size(75, 16);
            this.checkISO15693.TabIndex = 7;
            this.checkISO15693.Text = "ISO 15693";
            this.checkISO15693.UseVisualStyleBackColor = true;
            // 
            // checkFeliCa
            // 
            this.checkFeliCa.AutoSize = true;
            this.checkFeliCa.Checked = true;
            this.checkFeliCa.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkFeliCa.Location = new System.Drawing.Point(8, 80);
            this.checkFeliCa.Name = "checkFeliCa";
            this.checkFeliCa.Size = new System.Drawing.Size(54, 16);
            this.checkFeliCa.TabIndex = 13;
            this.checkFeliCa.Text = "FeliCa";
            this.checkFeliCa.UseVisualStyleBackColor = true;
            // 
            // checkISO14443A
            // 
            this.checkISO14443A.AutoSize = true;
            this.checkISO14443A.Checked = true;
            this.checkISO14443A.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkISO14443A.Location = new System.Drawing.Point(8, 38);
            this.checkISO14443A.Name = "checkISO14443A";
            this.checkISO14443A.Size = new System.Drawing.Size(83, 16);
            this.checkISO14443A.TabIndex = 8;
            this.checkISO14443A.Text = "ISO 14443A";
            this.checkISO14443A.UseVisualStyleBackColor = true;
            // 
            // checkISO14443B
            // 
            this.checkISO14443B.AutoSize = true;
            this.checkISO14443B.Checked = true;
            this.checkISO14443B.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkISO14443B.Location = new System.Drawing.Point(8, 59);
            this.checkISO14443B.Name = "checkISO14443B";
            this.checkISO14443B.Size = new System.Drawing.Size(83, 16);
            this.checkISO14443B.TabIndex = 9;
            this.checkISO14443B.Text = "ISO 14443B";
            this.checkISO14443B.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.labelModel);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.comboConnectBaudRate);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.btnConnect);
            this.groupBox1.Controls.Add(this.comboConnectType);
            this.groupBox1.Controls.Add(this.labelConStatus);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.btnDisconnect);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.comboConnectPort);
            this.groupBox1.Location = new System.Drawing.Point(9, 73);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(174, 174);
            this.groupBox1.TabIndex = 18;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Connect";
            // 
            // labelModel
            // 
            this.labelModel.AutoSize = true;
            this.labelModel.Location = new System.Drawing.Point(68, 154);
            this.labelModel.Name = "labelModel";
            this.labelModel.Size = new System.Drawing.Size(0, 12);
            this.labelModel.TabIndex = 16;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(18, 154);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(35, 12);
            this.label6.TabIndex = 15;
            this.label6.Text = "Model";
            // 
            // comboConnectBaudRate
            // 
            this.comboConnectBaudRate.Enabled = false;
            this.comboConnectBaudRate.FormattingEnabled = true;
            this.comboConnectBaudRate.Items.AddRange(new object[] {
            "4800",
            "9600",
            "19200",
            "38400",
            "115200"});
            this.comboConnectBaudRate.Location = new System.Drawing.Point(75, 68);
            this.comboConnectBaudRate.Name = "comboConnectBaudRate";
            this.comboConnectBaudRate.Size = new System.Drawing.Size(89, 20);
            this.comboConnectBaudRate.TabIndex = 14;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(17, 71);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(50, 12);
            this.label5.TabIndex = 13;
            this.label5.Text = "Baudrate:";
            // 
            // btnConnect
            // 
            this.btnConnect.Location = new System.Drawing.Point(9, 114);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(75, 30);
            this.btnConnect.TabIndex = 4;
            this.btnConnect.Text = "Connect";
            this.btnConnect.UseVisualStyleBackColor = true;
            this.btnConnect.Click += new System.EventHandler(this.btnConnect_Click);
            // 
            // comboConnectType
            // 
            this.comboConnectType.FormattingEnabled = true;
            this.comboConnectType.Items.AddRange(new object[] {
            "USB",
            "UART"});
            this.comboConnectType.Location = new System.Drawing.Point(75, 19);
            this.comboConnectType.Name = "comboConnectType";
            this.comboConnectType.Size = new System.Drawing.Size(89, 20);
            this.comboConnectType.TabIndex = 0;
            this.comboConnectType.Text = "USB";
            this.comboConnectType.SelectedIndexChanged += new System.EventHandler(this.comboConnectType_SelectedIndexChanged);
            // 
            // labelConStatus
            // 
            this.labelConStatus.AutoSize = true;
            this.labelConStatus.ForeColor = System.Drawing.Color.Red;
            this.labelConStatus.Location = new System.Drawing.Point(73, 96);
            this.labelConStatus.Name = "labelConStatus";
            this.labelConStatus.Size = new System.Drawing.Size(67, 12);
            this.labelConStatus.TabIndex = 11;
            this.labelConStatus.Text = "Disconnected";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(17, 96);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(32, 12);
            this.label4.TabIndex = 10;
            this.label4.Text = "Status";
            // 
            // btnDisconnect
            // 
            this.btnDisconnect.Enabled = false;
            this.btnDisconnect.Location = new System.Drawing.Point(88, 114);
            this.btnDisconnect.Name = "btnDisconnect";
            this.btnDisconnect.Size = new System.Drawing.Size(75, 30);
            this.btnDisconnect.TabIndex = 12;
            this.btnDisconnect.Text = "Disconnect";
            this.btnDisconnect.UseVisualStyleBackColor = true;
            this.btnDisconnect.Click += new System.EventHandler(this.btnDisconnect_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(17, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(32, 12);
            this.label1.TabIndex = 1;
            this.label1.Text = "Type:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(17, 47);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(27, 12);
            this.label2.TabIndex = 2;
            this.label2.Text = "Port:";
            // 
            // comboConnectPort
            // 
            this.comboConnectPort.FormattingEnabled = true;
            this.comboConnectPort.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6"});
            this.comboConnectPort.Location = new System.Drawing.Point(75, 44);
            this.comboConnectPort.Name = "comboConnectPort";
            this.comboConnectPort.Size = new System.Drawing.Size(89, 20);
            this.comboConnectPort.TabIndex = 3;
            this.comboConnectPort.Text = "0";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(25, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(149, 53);
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // tabMain
            // 
            this.tabMain.Controls.Add(this.tabPageInventory);
            this.tabMain.Controls.Add(this.tabPageBlockData);
            this.tabMain.Controls.Add(this.tabPageNFC);
            this.tabMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabMain.Location = new System.Drawing.Point(195, 0);
            this.tabMain.Name = "tabMain";
            this.tabMain.SelectedIndex = 0;
            this.tabMain.Size = new System.Drawing.Size(547, 446);
            this.tabMain.TabIndex = 2;
            // 
            // tabPageInventory
            // 
            this.tabPageInventory.Controls.Add(this.dgInventory);
            this.tabPageInventory.Controls.Add(this.btnInventoryStop);
            this.tabPageInventory.Controls.Add(this.btnInventoryClear);
            this.tabPageInventory.Controls.Add(this.btnInventoryRead);
            this.tabPageInventory.Location = new System.Drawing.Point(4, 22);
            this.tabPageInventory.Name = "tabPageInventory";
            this.tabPageInventory.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageInventory.Size = new System.Drawing.Size(539, 420);
            this.tabPageInventory.TabIndex = 0;
            this.tabPageInventory.Text = "Inventory";
            this.tabPageInventory.UseVisualStyleBackColor = true;
            // 
            // dgInventory
            // 
            this.dgInventory.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgInventory.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgInventory.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgInventory.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgInventory.Location = new System.Drawing.Point(11, 42);
            this.dgInventory.Name = "dgInventory";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgInventory.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgInventory.RowTemplate.Height = 24;
            this.dgInventory.Size = new System.Drawing.Size(346, 335);
            this.dgInventory.TabIndex = 14;
            // 
            // btnInventoryStop
            // 
            this.btnInventoryStop.Enabled = false;
            this.btnInventoryStop.Location = new System.Drawing.Point(138, 9);
            this.btnInventoryStop.Name = "btnInventoryStop";
            this.btnInventoryStop.Size = new System.Drawing.Size(91, 28);
            this.btnInventoryStop.TabIndex = 13;
            this.btnInventoryStop.Text = "Stop";
            this.btnInventoryStop.UseVisualStyleBackColor = true;
            this.btnInventoryStop.Click += new System.EventHandler(this.btnInventoryStop_Click);
            // 
            // btnInventoryClear
            // 
            this.btnInventoryClear.Location = new System.Drawing.Point(265, 9);
            this.btnInventoryClear.Name = "btnInventoryClear";
            this.btnInventoryClear.Size = new System.Drawing.Size(91, 28);
            this.btnInventoryClear.TabIndex = 12;
            this.btnInventoryClear.Text = "Clear";
            this.btnInventoryClear.UseVisualStyleBackColor = true;
            this.btnInventoryClear.Click += new System.EventHandler(this.btnInventoryClear_Click);
            // 
            // btnInventoryRead
            // 
            this.btnInventoryRead.Enabled = false;
            this.btnInventoryRead.Location = new System.Drawing.Point(11, 9);
            this.btnInventoryRead.Name = "btnInventoryRead";
            this.btnInventoryRead.Size = new System.Drawing.Size(91, 28);
            this.btnInventoryRead.TabIndex = 11;
            this.btnInventoryRead.Text = "Inventory";
            this.btnInventoryRead.UseVisualStyleBackColor = true;
            this.btnInventoryRead.Click += new System.EventHandler(this.btnInventoryRead_Click);
            // 
            // tabPageBlockData
            // 
            this.tabPageBlockData.Controls.Add(this.groupBox4);
            this.tabPageBlockData.Controls.Add(this.groupBox3);
            this.tabPageBlockData.Controls.Add(this.label13);
            this.tabPageBlockData.Controls.Add(this.label12);
            this.tabPageBlockData.Controls.Add(this.textBlockEnd);
            this.tabPageBlockData.Controls.Add(this.textBlockStart);
            this.tabPageBlockData.Controls.Add(this.btnBlockWrite);
            this.tabPageBlockData.Controls.Add(this.textBlockSize);
            this.tabPageBlockData.Controls.Add(this.label11);
            this.tabPageBlockData.Controls.Add(this.textBlockCount);
            this.tabPageBlockData.Controls.Add(this.label10);
            this.tabPageBlockData.Controls.Add(this.btnBlockGetUID);
            this.tabPageBlockData.Controls.Add(this.comboBlockUID);
            this.tabPageBlockData.Controls.Add(this.label9);
            this.tabPageBlockData.Controls.Add(this.btnBlockReadAll);
            this.tabPageBlockData.Controls.Add(this.dgBlk);
            this.tabPageBlockData.Location = new System.Drawing.Point(4, 22);
            this.tabPageBlockData.Name = "tabPageBlockData";
            this.tabPageBlockData.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageBlockData.Size = new System.Drawing.Size(539, 420);
            this.tabPageBlockData.TabIndex = 1;
            this.tabPageBlockData.Text = "Block Data";
            this.tabPageBlockData.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label15);
            this.groupBox4.Controls.Add(this.rdo64);
            this.groupBox4.Controls.Add(this.textPassword);
            this.groupBox4.Controls.Add(this.rdo32);
            this.groupBox4.Controls.Add(this.label14);
            this.groupBox4.Location = new System.Drawing.Point(381, 104);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(137, 87);
            this.groupBox4.TabIndex = 48;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Secure";
            this.groupBox4.Visible = false;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(7, 59);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(30, 12);
            this.label15.TabIndex = 5;
            this.label15.Text = "PWD";
            // 
            // rdo64
            // 
            this.rdo64.AutoSize = true;
            this.rdo64.Location = new System.Drawing.Point(39, 35);
            this.rdo64.Name = "rdo64";
            this.rdo64.Size = new System.Drawing.Size(54, 16);
            this.rdo64.TabIndex = 2;
            this.rdo64.TabStop = true;
            this.rdo64.Text = "64 bits";
            this.rdo64.UseVisualStyleBackColor = true;
            // 
            // textPassword
            // 
            this.textPassword.Location = new System.Drawing.Point(41, 56);
            this.textPassword.Name = "textPassword";
            this.textPassword.Size = new System.Drawing.Size(84, 22);
            this.textPassword.TabIndex = 4;
            // 
            // rdo32
            // 
            this.rdo32.AutoSize = true;
            this.rdo32.Location = new System.Drawing.Point(39, 15);
            this.rdo32.Name = "rdo32";
            this.rdo32.Size = new System.Drawing.Size(54, 16);
            this.rdo32.TabIndex = 1;
            this.rdo32.TabStop = true;
            this.rdo32.Text = "32 bits";
            this.rdo32.UseVisualStyleBackColor = true;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(8, 15);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(26, 12);
            this.label14.TabIndex = 0;
            this.label14.Text = "Len:";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.radioSecure);
            this.groupBox3.Controls.Add(this.radioFujitsu);
            this.groupBox3.Controls.Add(this.radioOption);
            this.groupBox3.Controls.Add(this.radioNormal);
            this.groupBox3.Location = new System.Drawing.Point(381, 6);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(137, 91);
            this.groupBox3.TabIndex = 47;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "15693 Option:";
            this.groupBox3.Visible = false;
            // 
            // radioSecure
            // 
            this.radioSecure.AutoSize = true;
            this.radioSecure.Location = new System.Drawing.Point(6, 70);
            this.radioSecure.Name = "radioSecure";
            this.radioSecure.Size = new System.Drawing.Size(54, 16);
            this.radioSecure.TabIndex = 3;
            this.radioSecure.Text = "Secure";
            this.radioSecure.UseVisualStyleBackColor = true;
            // 
            // radioFujitsu
            // 
            this.radioFujitsu.AutoSize = true;
            this.radioFujitsu.Location = new System.Drawing.Point(6, 51);
            this.radioFujitsu.Name = "radioFujitsu";
            this.radioFujitsu.Size = new System.Drawing.Size(108, 16);
            this.radioFujitsu.TabIndex = 2;
            this.radioFujitsu.Text = "Fujitsu_Fast Mode";
            this.radioFujitsu.UseVisualStyleBackColor = true;
            // 
            // radioOption
            // 
            this.radioOption.AutoSize = true;
            this.radioOption.Location = new System.Drawing.Point(6, 32);
            this.radioOption.Name = "radioOption";
            this.radioOption.Size = new System.Drawing.Size(113, 16);
            this.radioOption.TabIndex = 1;
            this.radioOption.Text = "Option Flag Enable";
            this.radioOption.UseVisualStyleBackColor = true;
            // 
            // radioNormal
            // 
            this.radioNormal.AutoSize = true;
            this.radioNormal.Checked = true;
            this.radioNormal.Location = new System.Drawing.Point(6, 13);
            this.radioNormal.Name = "radioNormal";
            this.radioNormal.Size = new System.Drawing.Size(58, 16);
            this.radioNormal.TabIndex = 0;
            this.radioNormal.TabStop = true;
            this.radioNormal.Text = "Normal";
            this.radioNormal.UseVisualStyleBackColor = true;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(194, 63);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(21, 12);
            this.label13.TabIndex = 46;
            this.label13.Text = "To:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(101, 63);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(33, 12);
            this.label12.TabIndex = 45;
            this.label12.Text = "From:";
            // 
            // textBlockEnd
            // 
            this.textBlockEnd.Location = new System.Drawing.Point(221, 63);
            this.textBlockEnd.Name = "textBlockEnd";
            this.textBlockEnd.Size = new System.Drawing.Size(36, 22);
            this.textBlockEnd.TabIndex = 44;
            // 
            // textBlockStart
            // 
            this.textBlockStart.Location = new System.Drawing.Point(137, 63);
            this.textBlockStart.Name = "textBlockStart";
            this.textBlockStart.Size = new System.Drawing.Size(36, 22);
            this.textBlockStart.TabIndex = 43;
            // 
            // btnBlockWrite
            // 
            this.btnBlockWrite.Enabled = false;
            this.btnBlockWrite.Location = new System.Drawing.Point(272, 63);
            this.btnBlockWrite.Name = "btnBlockWrite";
            this.btnBlockWrite.Size = new System.Drawing.Size(92, 25);
            this.btnBlockWrite.TabIndex = 42;
            this.btnBlockWrite.Text = "Write";
            this.btnBlockWrite.UseVisualStyleBackColor = true;
            this.btnBlockWrite.Click += new System.EventHandler(this.btnBlockWrite_Click);
            // 
            // textBlockSize
            // 
            this.textBlockSize.Location = new System.Drawing.Point(221, 35);
            this.textBlockSize.Name = "textBlockSize";
            this.textBlockSize.Size = new System.Drawing.Size(36, 22);
            this.textBlockSize.TabIndex = 40;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(151, 38);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(64, 12);
            this.label11.TabIndex = 39;
            this.label11.Text = "Size (Bytes):";
            // 
            // textBlockCount
            // 
            this.textBlockCount.Location = new System.Drawing.Point(84, 36);
            this.textBlockCount.Name = "textBlockCount";
            this.textBlockCount.Size = new System.Drawing.Size(35, 22);
            this.textBlockCount.TabIndex = 38;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(13, 38);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(68, 12);
            this.label10.TabIndex = 37;
            this.label10.Text = "Block Count:";
            // 
            // btnBlockGetUID
            // 
            this.btnBlockGetUID.Location = new System.Drawing.Point(272, 7);
            this.btnBlockGetUID.Name = "btnBlockGetUID";
            this.btnBlockGetUID.Size = new System.Drawing.Size(92, 25);
            this.btnBlockGetUID.TabIndex = 36;
            this.btnBlockGetUID.Text = "Get UID";
            this.btnBlockGetUID.UseVisualStyleBackColor = true;
            this.btnBlockGetUID.Click += new System.EventHandler(this.btnBlockGetUID_Click);
            // 
            // comboBlockUID
            // 
            this.comboBlockUID.FormattingEnabled = true;
            this.comboBlockUID.Location = new System.Drawing.Point(48, 10);
            this.comboBlockUID.Name = "comboBlockUID";
            this.comboBlockUID.Size = new System.Drawing.Size(209, 20);
            this.comboBlockUID.TabIndex = 35;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(13, 10);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(28, 12);
            this.label9.TabIndex = 34;
            this.label9.Text = "UID:";
            // 
            // btnBlockReadAll
            // 
            this.btnBlockReadAll.Enabled = false;
            this.btnBlockReadAll.Location = new System.Drawing.Point(272, 35);
            this.btnBlockReadAll.Name = "btnBlockReadAll";
            this.btnBlockReadAll.Size = new System.Drawing.Size(92, 25);
            this.btnBlockReadAll.TabIndex = 33;
            this.btnBlockReadAll.Text = "Read All";
            this.btnBlockReadAll.UseVisualStyleBackColor = true;
            this.btnBlockReadAll.Click += new System.EventHandler(this.btnBlockReadAll_Click);
            // 
            // dgBlk
            // 
            this.dgBlk.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgBlk.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dgBlk.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgBlk.DefaultCellStyle = dataGridViewCellStyle5;
            this.dgBlk.Location = new System.Drawing.Point(8, 95);
            this.dgBlk.Name = "dgBlk";
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgBlk.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.dgBlk.RowTemplate.Height = 24;
            this.dgBlk.Size = new System.Drawing.Size(363, 282);
            this.dgBlk.TabIndex = 32;
            // 
            // tabPageNFC
            // 
            this.tabPageNFC.Controls.Add(this.labelFileMessage);
            this.tabPageNFC.Controls.Add(this.pictureBoxNFC);
            this.tabPageNFC.Controls.Add(this.groupBox7);
            this.tabPageNFC.Controls.Add(this.groupBox6);
            this.tabPageNFC.Location = new System.Drawing.Point(4, 22);
            this.tabPageNFC.Name = "tabPageNFC";
            this.tabPageNFC.Size = new System.Drawing.Size(539, 420);
            this.tabPageNFC.TabIndex = 2;
            this.tabPageNFC.Text = "NFC";
            this.tabPageNFC.UseVisualStyleBackColor = true;
            // 
            // labelFileMessage
            // 
            this.labelFileMessage.AutoSize = true;
            this.labelFileMessage.ForeColor = System.Drawing.Color.Red;
            this.labelFileMessage.Location = new System.Drawing.Point(19, 120);
            this.labelFileMessage.Name = "labelFileMessage";
            this.labelFileMessage.Size = new System.Drawing.Size(0, 12);
            this.labelFileMessage.TabIndex = 8;
            // 
            // pictureBoxNFC
            // 
            this.pictureBoxNFC.Location = new System.Drawing.Point(257, 19);
            this.pictureBoxNFC.Name = "pictureBoxNFC";
            this.pictureBoxNFC.Size = new System.Drawing.Size(258, 216);
            this.pictureBoxNFC.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBoxNFC.TabIndex = 7;
            this.pictureBoxNFC.TabStop = false;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.btnFileBrowserR);
            this.groupBox7.Controls.Add(this.barRx);
            this.groupBox7.Controls.Add(this.txtReceiveFilename);
            this.groupBox7.Controls.Add(this.label18);
            this.groupBox7.Controls.Add(this.txtReceivePath);
            this.groupBox7.Controls.Add(this.label17);
            this.groupBox7.Controls.Add(this.btnReceive);
            this.groupBox7.Location = new System.Drawing.Point(10, 146);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(237, 127);
            this.groupBox7.TabIndex = 6;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Receive";
            // 
            // btnFileBrowserR
            // 
            this.btnFileBrowserR.Location = new System.Drawing.Point(203, 10);
            this.btnFileBrowserR.Name = "btnFileBrowserR";
            this.btnFileBrowserR.Size = new System.Drawing.Size(27, 23);
            this.btnFileBrowserR.TabIndex = 7;
            this.btnFileBrowserR.Text = "...";
            this.btnFileBrowserR.UseVisualStyleBackColor = true;
            this.btnFileBrowserR.Click += new System.EventHandler(this.btnFileBrowserR_Click);
            // 
            // barRx
            // 
            this.barRx.Location = new System.Drawing.Point(11, 63);
            this.barRx.Name = "barRx";
            this.barRx.Size = new System.Drawing.Size(213, 21);
            this.barRx.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            this.barRx.TabIndex = 6;
            // 
            // txtReceiveFilename
            // 
            this.txtReceiveFilename.Location = new System.Drawing.Point(59, 36);
            this.txtReceiveFilename.Name = "txtReceiveFilename";
            this.txtReceiveFilename.Size = new System.Drawing.Size(165, 22);
            this.txtReceiveFilename.TabIndex = 5;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(8, 39);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(49, 12);
            this.label18.TabIndex = 4;
            this.label18.Text = "FileName";
            // 
            // txtReceivePath
            // 
            this.txtReceivePath.Location = new System.Drawing.Point(59, 12);
            this.txtReceivePath.Name = "txtReceivePath";
            this.txtReceivePath.Size = new System.Drawing.Size(138, 22);
            this.txtReceivePath.TabIndex = 3;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(8, 15);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(42, 12);
            this.label17.TabIndex = 2;
            this.label17.Text = "FilePath";
            // 
            // btnReceive
            // 
            this.btnReceive.Enabled = false;
            this.btnReceive.Location = new System.Drawing.Point(59, 93);
            this.btnReceive.Name = "btnReceive";
            this.btnReceive.Size = new System.Drawing.Size(129, 22);
            this.btnReceive.TabIndex = 1;
            this.btnReceive.Text = "Receive";
            this.btnReceive.UseVisualStyleBackColor = true;
            this.btnReceive.Click += new System.EventHandler(this.btnReceive_Click);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.btnFileBrowserS);
            this.groupBox6.Controls.Add(this.barTx);
            this.groupBox6.Controls.Add(this.txtSendFilename);
            this.groupBox6.Controls.Add(this.label16);
            this.groupBox6.Controls.Add(this.btnSend);
            this.groupBox6.Location = new System.Drawing.Point(10, 7);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(237, 94);
            this.groupBox6.TabIndex = 5;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Send";
            // 
            // btnFileBrowserS
            // 
            this.btnFileBrowserS.Location = new System.Drawing.Point(203, 12);
            this.btnFileBrowserS.Name = "btnFileBrowserS";
            this.btnFileBrowserS.Size = new System.Drawing.Size(27, 23);
            this.btnFileBrowserS.TabIndex = 4;
            this.btnFileBrowserS.Text = "...";
            this.btnFileBrowserS.UseVisualStyleBackColor = true;
            this.btnFileBrowserS.Click += new System.EventHandler(this.btnFileBrowserS_Click);
            // 
            // barTx
            // 
            this.barTx.Location = new System.Drawing.Point(11, 39);
            this.barTx.Name = "barTx";
            this.barTx.Size = new System.Drawing.Size(213, 21);
            this.barTx.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            this.barTx.TabIndex = 3;
            // 
            // txtSendFilename
            // 
            this.txtSendFilename.Location = new System.Drawing.Point(59, 12);
            this.txtSendFilename.Name = "txtSendFilename";
            this.txtSendFilename.Size = new System.Drawing.Size(138, 22);
            this.txtSendFilename.TabIndex = 2;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(8, 15);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(49, 12);
            this.label16.TabIndex = 1;
            this.label16.Text = "FileName";
            // 
            // btnSend
            // 
            this.btnSend.Enabled = false;
            this.btnSend.Location = new System.Drawing.Point(59, 67);
            this.btnSend.Name = "btnSend";
            this.btnSend.Size = new System.Drawing.Size(129, 21);
            this.btnSend.TabIndex = 0;
            this.btnSend.Text = "Send";
            this.btnSend.UseVisualStyleBackColor = true;
            this.btnSend.Click += new System.EventHandler(this.btnSend_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // timer_Beep
            // 
            this.timer_Beep.Interval = 300;
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(742, 446);
            this.Controls.Add(this.tabMain);
            this.Controls.Add(this.panelMain);
            this.Name = "frmMain";
            this.Text = "ClarIDy HF RFID-NFC Demo";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.panelMain.ResumeLayout(false);
            this.panelMain.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tabMain.ResumeLayout(false);
            this.tabPageInventory.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgInventory)).EndInit();
            this.tabPageBlockData.ResumeLayout(false);
            this.tabPageBlockData.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgBlk)).EndInit();
            this.tabPageNFC.ResumeLayout(false);
            this.tabPageNFC.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxNFC)).EndInit();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelMain;
        private System.Windows.Forms.CheckBox checkLed;
        private System.Windows.Forms.CheckBox checkBeep;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label lbVer;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.CheckBox checkISO15693;
        private System.Windows.Forms.CheckBox checkFeliCa;
        private System.Windows.Forms.CheckBox checkISO14443A;
        private System.Windows.Forms.CheckBox checkISO14443B;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label labelModel;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox comboConnectBaudRate;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnConnect;
        private System.Windows.Forms.ComboBox comboConnectType;
        private System.Windows.Forms.Label labelConStatus;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnDisconnect;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboConnectPort;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TabControl tabMain;
        private System.Windows.Forms.TabPage tabPageInventory;
        private System.Windows.Forms.DataGridView dgInventory;
        private System.Windows.Forms.Button btnInventoryStop;
        private System.Windows.Forms.Button btnInventoryClear;
        private System.Windows.Forms.Button btnInventoryRead;
        private System.Windows.Forms.TabPage tabPageBlockData;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.RadioButton rdo64;
        private System.Windows.Forms.TextBox textPassword;
        private System.Windows.Forms.RadioButton rdo32;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.RadioButton radioSecure;
        private System.Windows.Forms.RadioButton radioFujitsu;
        private System.Windows.Forms.RadioButton radioOption;
        private System.Windows.Forms.RadioButton radioNormal;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBlockEnd;
        private System.Windows.Forms.TextBox textBlockStart;
        private System.Windows.Forms.Button btnBlockWrite;
        private System.Windows.Forms.TextBox textBlockSize;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBlockCount;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button btnBlockGetUID;
        private System.Windows.Forms.ComboBox comboBlockUID;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnBlockReadAll;
        private System.Windows.Forms.DataGridView dgBlk;
        private System.Windows.Forms.TabPage tabPageNFC;
        private System.Windows.Forms.Label labelFileMessage;
        private System.Windows.Forms.PictureBox pictureBoxNFC;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Button btnFileBrowserR;
        private System.Windows.Forms.ProgressBar barRx;
        private System.Windows.Forms.TextBox txtReceiveFilename;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtReceivePath;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button btnReceive;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Button btnFileBrowserS;
        private System.Windows.Forms.ProgressBar barTx;
        private System.Windows.Forms.TextBox txtSendFilename;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button btnSend;
        private System.Windows.Forms.Timer timer43B;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Timer timer_Beep;
        private System.Windows.Forms.Timer timer_LED;
    }
}

