﻿namespace ClarIDy_HF_Demo
{
    partial class TopPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TopPage));
            this.lblUserID = new System.Windows.Forms.Label();
            this.lblPwd = new System.Windows.Forms.Label();
            this.lblNickname = new System.Windows.Forms.Label();
            this.txbNickname = new System.Windows.Forms.TextBox();
            this.txbUserID = new System.Windows.Forms.TextBox();
            this.txbPwd = new System.Windows.Forms.TextBox();
            this.btnSign = new System.Windows.Forms.Button();
            this.btnIntro = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.lblRfid = new System.Windows.Forms.Label();
            this.txbRfid = new System.Windows.Forms.TextBox();
            this.lblTest = new System.Windows.Forms.Label();
            this.pictPink = new System.Windows.Forms.PictureBox();
            this.pictBlue = new System.Windows.Forms.PictureBox();
            this.pictUser = new System.Windows.Forms.PictureBox();
            this.lblWarning1 = new System.Windows.Forms.Label();
            this.lblWarning2 = new System.Windows.Forms.Label();
            this.lblWarning3 = new System.Windows.Forms.Label();
            this.lblWarning4 = new System.Windows.Forms.Label();
            this.lblWarning5 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txbCheckPwd = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblCheckPwd = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictPink)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictBlue)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictUser)).BeginInit();
            this.SuspendLayout();
            // 
            // lblUserID
            // 
            this.lblUserID.AutoSize = true;
            this.lblUserID.BackColor = System.Drawing.Color.Transparent;
            this.lblUserID.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblUserID.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lblUserID.Location = new System.Drawing.Point(244, 225);
            this.lblUserID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblUserID.Name = "lblUserID";
            this.lblUserID.Size = new System.Drawing.Size(90, 21);
            this.lblUserID.TabIndex = 2;
            this.lblUserID.Text = "電子郵件：";
            // 
            // lblPwd
            // 
            this.lblPwd.AutoSize = true;
            this.lblPwd.BackColor = System.Drawing.Color.Transparent;
            this.lblPwd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblPwd.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblPwd.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lblPwd.Location = new System.Drawing.Point(244, 267);
            this.lblPwd.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPwd.Name = "lblPwd";
            this.lblPwd.Size = new System.Drawing.Size(58, 21);
            this.lblPwd.TabIndex = 3;
            this.lblPwd.Text = "密碼：";
            // 
            // lblNickname
            // 
            this.lblNickname.AutoSize = true;
            this.lblNickname.BackColor = System.Drawing.Color.Transparent;
            this.lblNickname.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblNickname.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lblNickname.Location = new System.Drawing.Point(244, 182);
            this.lblNickname.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNickname.Name = "lblNickname";
            this.lblNickname.Size = new System.Drawing.Size(58, 21);
            this.lblNickname.TabIndex = 4;
            this.lblNickname.Text = "名稱：";
            // 
            // txbNickname
            // 
            this.txbNickname.BackColor = System.Drawing.SystemColors.Info;
            this.txbNickname.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txbNickname.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txbNickname.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.txbNickname.Location = new System.Drawing.Point(371, 182);
            this.txbNickname.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txbNickname.Name = "txbNickname";
            this.txbNickname.Size = new System.Drawing.Size(148, 22);
            this.txbNickname.TabIndex = 5;
            // 
            // txbUserID
            // 
            this.txbUserID.BackColor = System.Drawing.SystemColors.Info;
            this.txbUserID.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txbUserID.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txbUserID.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.txbUserID.Location = new System.Drawing.Point(371, 225);
            this.txbUserID.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txbUserID.Name = "txbUserID";
            this.txbUserID.Size = new System.Drawing.Size(148, 22);
            this.txbUserID.TabIndex = 6;
            this.txbUserID.TextChanged += new System.EventHandler(this.txbUserID_TextChanged);
            // 
            // txbPwd
            // 
            this.txbPwd.BackColor = System.Drawing.SystemColors.Info;
            this.txbPwd.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txbPwd.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txbPwd.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.txbPwd.Location = new System.Drawing.Point(371, 267);
            this.txbPwd.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txbPwd.Name = "txbPwd";
            this.txbPwd.Size = new System.Drawing.Size(148, 22);
            this.txbPwd.TabIndex = 7;
            // 
            // btnSign
            // 
            this.btnSign.BackColor = System.Drawing.Color.Tan;
            this.btnSign.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnSign.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnSign.Location = new System.Drawing.Point(394, 389);
            this.btnSign.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnSign.Name = "btnSign";
            this.btnSign.Size = new System.Drawing.Size(121, 37);
            this.btnSign.TabIndex = 8;
            this.btnSign.Text = "註冊";
            this.btnSign.UseVisualStyleBackColor = false;
            this.btnSign.Click += new System.EventHandler(this.btnSign_Click);
            // 
            // btnIntro
            // 
            this.btnIntro.BackColor = System.Drawing.Color.Tan;
            this.btnIntro.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnIntro.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnIntro.Location = new System.Drawing.Point(266, 436);
            this.btnIntro.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnIntro.Name = "btnIntro";
            this.btnIntro.Size = new System.Drawing.Size(249, 37);
            this.btnIntro.TabIndex = 10;
            this.btnIntro.Text = "遊戲介紹";
            this.btnIntro.UseVisualStyleBackColor = false;
            this.btnIntro.Click += new System.EventHandler(this.btnIntro_Click);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // lblRfid
            // 
            this.lblRfid.AutoSize = true;
            this.lblRfid.BackColor = System.Drawing.Color.Transparent;
            this.lblRfid.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblRfid.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lblRfid.Location = new System.Drawing.Point(244, 353);
            this.lblRfid.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblRfid.Name = "lblRfid";
            this.lblRfid.Size = new System.Drawing.Size(106, 21);
            this.lblRfid.TabIndex = 11;
            this.lblRfid.Text = "綁定學生證：";
            // 
            // txbRfid
            // 
            this.txbRfid.BackColor = System.Drawing.SystemColors.Info;
            this.txbRfid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txbRfid.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txbRfid.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.txbRfid.Location = new System.Drawing.Point(371, 349);
            this.txbRfid.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txbRfid.Name = "txbRfid";
            this.txbRfid.Size = new System.Drawing.Size(148, 22);
            this.txbRfid.TabIndex = 12;
            this.txbRfid.MouseClick += new System.Windows.Forms.MouseEventHandler(this.txbRfid_MouseClick);
            // 
            // lblTest
            // 
            this.lblTest.AutoSize = true;
            this.lblTest.BackColor = System.Drawing.Color.Transparent;
            this.lblTest.Location = new System.Drawing.Point(362, 371);
            this.lblTest.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTest.Name = "lblTest";
            this.lblTest.Size = new System.Drawing.Size(0, 16);
            this.lblTest.TabIndex = 15;
            // 
            // pictPink
            // 
            this.pictPink.BackColor = System.Drawing.Color.Transparent;
            this.pictPink.Image = ((System.Drawing.Image)(resources.GetObject("pictPink.Image")));
            this.pictPink.Location = new System.Drawing.Point(130, 348);
            this.pictPink.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictPink.Name = "pictPink";
            this.pictPink.Size = new System.Drawing.Size(75, 75);
            this.pictPink.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictPink.TabIndex = 14;
            this.pictPink.TabStop = false;
            this.pictPink.Click += new System.EventHandler(this.pictPink_Click);
            // 
            // pictBlue
            // 
            this.pictBlue.BackColor = System.Drawing.Color.Transparent;
            this.pictBlue.Image = ((System.Drawing.Image)(resources.GetObject("pictBlue.Image")));
            this.pictBlue.Location = new System.Drawing.Point(49, 348);
            this.pictBlue.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictBlue.Name = "pictBlue";
            this.pictBlue.Size = new System.Drawing.Size(75, 75);
            this.pictBlue.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictBlue.TabIndex = 13;
            this.pictBlue.TabStop = false;
            this.pictBlue.Click += new System.EventHandler(this.pictBlue_Click);
            // 
            // pictUser
            // 
            this.pictUser.BackColor = System.Drawing.Color.Transparent;
            this.pictUser.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictUser.ImageLocation = "";
            this.pictUser.Location = new System.Drawing.Point(49, 201);
            this.pictUser.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictUser.Name = "pictUser";
            this.pictUser.Size = new System.Drawing.Size(156, 137);
            this.pictUser.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictUser.TabIndex = 0;
            this.pictUser.TabStop = false;
            // 
            // lblWarning1
            // 
            this.lblWarning1.AutoSize = true;
            this.lblWarning1.Location = new System.Drawing.Point(371, 203);
            this.lblWarning1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblWarning1.Name = "lblWarning1";
            this.lblWarning1.Size = new System.Drawing.Size(0, 16);
            this.lblWarning1.TabIndex = 16;
            // 
            // lblWarning2
            // 
            this.lblWarning2.AutoSize = true;
            this.lblWarning2.Location = new System.Drawing.Point(371, 242);
            this.lblWarning2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblWarning2.Name = "lblWarning2";
            this.lblWarning2.Size = new System.Drawing.Size(0, 16);
            this.lblWarning2.TabIndex = 17;
            // 
            // lblWarning3
            // 
            this.lblWarning3.AutoSize = true;
            this.lblWarning3.Location = new System.Drawing.Point(371, 288);
            this.lblWarning3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblWarning3.Name = "lblWarning3";
            this.lblWarning3.Size = new System.Drawing.Size(0, 16);
            this.lblWarning3.TabIndex = 18;
            // 
            // lblWarning4
            // 
            this.lblWarning4.AutoSize = true;
            this.lblWarning4.Location = new System.Drawing.Point(362, 374);
            this.lblWarning4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblWarning4.Name = "lblWarning4";
            this.lblWarning4.Size = new System.Drawing.Size(0, 16);
            this.lblWarning4.TabIndex = 19;
            // 
            // lblWarning5
            // 
            this.lblWarning5.AutoSize = true;
            this.lblWarning5.Location = new System.Drawing.Point(46, 428);
            this.lblWarning5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblWarning5.Name = "lblWarning5";
            this.lblWarning5.Size = new System.Drawing.Size(0, 16);
            this.lblWarning5.TabIndex = 20;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("微軟正黑體", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(226)))), ((int)(((byte)(211)))));
            this.label1.Location = new System.Drawing.Point(112, 38);
            this.label1.Name = "label1";
            this.label1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label1.Size = new System.Drawing.Size(81, 40);
            this.label1.TabIndex = 21;
            this.label1.Text = "註冊";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(371, 329);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 16);
            this.label2.TabIndex = 24;
            // 
            // txbCheckPwd
            // 
            this.txbCheckPwd.BackColor = System.Drawing.SystemColors.Info;
            this.txbCheckPwd.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txbCheckPwd.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txbCheckPwd.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.txbCheckPwd.Location = new System.Drawing.Point(371, 309);
            this.txbCheckPwd.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txbCheckPwd.Name = "txbCheckPwd";
            this.txbCheckPwd.Size = new System.Drawing.Size(148, 22);
            this.txbCheckPwd.TabIndex = 23;
            this.txbCheckPwd.TextChanged += new System.EventHandler(this.txbCheckPwd_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label3.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label3.Location = new System.Drawing.Point(244, 309);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(90, 21);
            this.label3.TabIndex = 22;
            this.label3.Text = "確認密碼：";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("微軟正黑體", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label4.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label4.Location = new System.Drawing.Point(297, 405);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(90, 21);
            this.label4.TabIndex = 25;
            this.label4.Text = "已有帳號？";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // lblCheckPwd
            // 
            this.lblCheckPwd.AutoSize = true;
            this.lblCheckPwd.Location = new System.Drawing.Point(371, 330);
            this.lblCheckPwd.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCheckPwd.Name = "lblCheckPwd";
            this.lblCheckPwd.Size = new System.Drawing.Size(0, 16);
            this.lblCheckPwd.TabIndex = 26;
            // 
            // TopPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(614, 554);
            this.Controls.Add(this.lblCheckPwd);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txbCheckPwd);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblWarning5);
            this.Controls.Add(this.lblWarning4);
            this.Controls.Add(this.lblWarning3);
            this.Controls.Add(this.lblWarning2);
            this.Controls.Add(this.lblWarning1);
            this.Controls.Add(this.lblTest);
            this.Controls.Add(this.pictPink);
            this.Controls.Add(this.pictBlue);
            this.Controls.Add(this.txbRfid);
            this.Controls.Add(this.lblRfid);
            this.Controls.Add(this.btnIntro);
            this.Controls.Add(this.btnSign);
            this.Controls.Add(this.txbPwd);
            this.Controls.Add(this.txbUserID);
            this.Controls.Add(this.txbNickname);
            this.Controls.Add(this.lblNickname);
            this.Controls.Add(this.lblPwd);
            this.Controls.Add(this.lblUserID);
            this.Controls.Add(this.pictUser);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "TopPage";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "\"Hello World - Taiwan!\"";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.TopPage_FormClosing);
            this.Load += new System.EventHandler(this.TopPage_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictPink)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictBlue)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictUser)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictUser;
        private System.Windows.Forms.Label lblUserID;
        private System.Windows.Forms.Label lblPwd;
        private System.Windows.Forms.Label lblNickname;
        private System.Windows.Forms.TextBox txbNickname;
        private System.Windows.Forms.TextBox txbUserID;
        private System.Windows.Forms.TextBox txbPwd;
        private System.Windows.Forms.Button btnSign;
        private System.Windows.Forms.Button btnIntro;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label lblRfid;
        private System.Windows.Forms.TextBox txbRfid;
        private System.Windows.Forms.PictureBox pictBlue;
        private System.Windows.Forms.PictureBox pictPink;
        private System.Windows.Forms.Label lblTest;
        private System.Windows.Forms.Label lblWarning1;
        private System.Windows.Forms.Label lblWarning2;
        private System.Windows.Forms.Label lblWarning3;
        private System.Windows.Forms.Label lblWarning4;
        private System.Windows.Forms.Label lblWarning5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txbCheckPwd;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblCheckPwd;
    }
}