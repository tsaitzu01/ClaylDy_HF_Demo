﻿using ClarIDy_HF_Demo;
using MySql.Data.MySqlClient;
using RFID_HF_SDK;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ClarIDy_HF_DEMO
{
    public partial class LoginByAccount : Form
    {
        MySqlConnection connection;
        bool isEmail;

        public LoginByAccount()
        {
            InitializeComponent();
            txbPwd.PasswordChar = '\u25CF';
            string connectionString = "server=120.126.18.177; database=player; uid=root; pwd=root";
            //string connectionString = "server=192.168.231.98; database=player; uid=root; pwd=root";
            connection = new MySqlConnection(connectionString);
        }

        private void lblByCard_Click(object sender, EventArgs e)
        {
            LoginByCard frm = new LoginByCard();
            frm.Show();
            this.Close();
        }


        private void btnLogin_Click(object sender, EventArgs e)
        {
            isEmail = Regex.IsMatch(txbUserId.Text, @"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z", RegexOptions.IgnoreCase);
            if (txbUserId.Text == string.Empty || txbPwd.Text == string.Empty)
            {
                lblWarning.Text = "請輸入帳號及密碼";
                connection.Close();
                return;
            }
            else if (!isEmail)
            {
                lblTest.Text = "電子郵件格式不符合";
                connection.Close();
                return;
            }else
                lblTest.Text = "";
            string selectPassword = "select password from player_data where email = @email";
            MySqlCommand command = new MySqlCommand(selectPassword, connection);
            command.Parameters.AddWithValue("@email", txbUserId.Text);
            connection.Open();
            Object password = command.ExecuteScalar();
            if (password == null)
                lblTest.Text = "帳號尚未註冊";
            else if(password.ToString() == txbPwd.Text)
            {
                MyPage frm = new MyPage(txbUserId.Text);
                frm.Show();
                this.Close();
            }
            else
                lblWarning.Text = "密碼錯誤，請重新嘗試";
            connection.Close();
        }

        private void txbUserId_TextChanged(object sender, EventArgs e)
        {

        }

        private void txbPwd_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {
            TopPage frm = new TopPage();
            frm.Show();
            this.Close();
        }

        private void btnIntro_Click(object sender, EventArgs e)
        {
            IntroPage frm = new IntroPage();
            frm.Show();
            //this.Hide();
        }
    }
}
