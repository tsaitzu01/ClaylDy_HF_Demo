﻿namespace ClarIDy_HF_DEMO
{
    partial class LoginByAccount
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LoginByAccount));
            this.txbPwd = new System.Windows.Forms.TextBox();
            this.lblPwd = new System.Windows.Forms.Label();
            this.lblByCard = new System.Windows.Forms.Label();
            this.lblUserId = new System.Windows.Forms.Label();
            this.txbUserId = new System.Windows.Forms.TextBox();
            this.btnLogin = new System.Windows.Forms.Button();
            this.lblTest = new System.Windows.Forms.Label();
            this.lblWarning = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnIntro = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txbPwd
            // 
            this.txbPwd.BackColor = System.Drawing.SystemColors.Info;
            this.txbPwd.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txbPwd.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txbPwd.Location = new System.Drawing.Point(193, 193);
            this.txbPwd.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txbPwd.Name = "txbPwd";
            this.txbPwd.Size = new System.Drawing.Size(212, 22);
            this.txbPwd.TabIndex = 0;
            this.txbPwd.TextChanged += new System.EventHandler(this.txbPwd_TextChanged);
            // 
            // lblPwd
            // 
            this.lblPwd.AutoSize = true;
            this.lblPwd.BackColor = System.Drawing.Color.Transparent;
            this.lblPwd.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblPwd.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lblPwd.Location = new System.Drawing.Point(112, 194);
            this.lblPwd.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPwd.Name = "lblPwd";
            this.lblPwd.Size = new System.Drawing.Size(58, 21);
            this.lblPwd.TabIndex = 1;
            this.lblPwd.Text = "密碼：";
            // 
            // lblByCard
            // 
            this.lblByCard.AutoSize = true;
            this.lblByCard.BackColor = System.Drawing.Color.Transparent;
            this.lblByCard.Font = new System.Drawing.Font("微軟正黑體", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblByCard.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lblByCard.Location = new System.Drawing.Point(92, 250);
            this.lblByCard.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblByCard.Name = "lblByCard";
            this.lblByCard.Size = new System.Drawing.Size(106, 21);
            this.lblByCard.TabIndex = 2;
            this.lblByCard.Text = "以學生證登入";
            this.lblByCard.Click += new System.EventHandler(this.lblByCard_Click);
            // 
            // lblUserId
            // 
            this.lblUserId.AutoSize = true;
            this.lblUserId.BackColor = System.Drawing.Color.Transparent;
            this.lblUserId.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblUserId.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lblUserId.Location = new System.Drawing.Point(80, 138);
            this.lblUserId.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblUserId.Name = "lblUserId";
            this.lblUserId.Size = new System.Drawing.Size(90, 21);
            this.lblUserId.TabIndex = 4;
            this.lblUserId.Text = "電子郵件：";
            // 
            // txbUserId
            // 
            this.txbUserId.BackColor = System.Drawing.SystemColors.Info;
            this.txbUserId.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txbUserId.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txbUserId.Location = new System.Drawing.Point(193, 139);
            this.txbUserId.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txbUserId.Name = "txbUserId";
            this.txbUserId.Size = new System.Drawing.Size(212, 22);
            this.txbUserId.TabIndex = 3;
            this.txbUserId.TextChanged += new System.EventHandler(this.txbUserId_TextChanged);
            // 
            // btnLogin
            // 
            this.btnLogin.BackColor = System.Drawing.Color.Tan;
            this.btnLogin.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnLogin.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnLogin.Location = new System.Drawing.Point(223, 245);
            this.btnLogin.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(182, 49);
            this.btnLogin.TabIndex = 5;
            this.btnLogin.Text = "登入";
            this.btnLogin.UseVisualStyleBackColor = false;
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
            // 
            // lblTest
            // 
            this.lblTest.AutoSize = true;
            this.lblTest.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblTest.Location = new System.Drawing.Point(172, 173);
            this.lblTest.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTest.Name = "lblTest";
            this.lblTest.Size = new System.Drawing.Size(0, 16);
            this.lblTest.TabIndex = 12;
            // 
            // lblWarning
            // 
            this.lblWarning.AutoSize = true;
            this.lblWarning.Location = new System.Drawing.Point(159, 227);
            this.lblWarning.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblWarning.Name = "lblWarning";
            this.lblWarning.Size = new System.Drawing.Size(0, 16);
            this.lblWarning.TabIndex = 13;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("微軟正黑體", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(226)))), ((int)(((byte)(211)))));
            this.label1.Location = new System.Drawing.Point(18, 25);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label1.Size = new System.Drawing.Size(81, 40);
            this.label1.TabIndex = 22;
            this.label1.Text = "登入";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("微軟正黑體", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label2.Location = new System.Drawing.Point(114, 277);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 21);
            this.label2.TabIndex = 23;
            this.label2.Text = "尚未註冊?";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // btnIntro
            // 
            this.btnIntro.BackColor = System.Drawing.Color.Tan;
            this.btnIntro.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnIntro.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnIntro.Location = new System.Drawing.Point(223, 304);
            this.btnIntro.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.btnIntro.Name = "btnIntro";
            this.btnIntro.Size = new System.Drawing.Size(182, 49);
            this.btnIntro.TabIndex = 26;
            this.btnIntro.Text = "遊戲介紹";
            this.btnIntro.UseVisualStyleBackColor = false;
            this.btnIntro.Click += new System.EventHandler(this.btnIntro_Click);
            // 
            // LoginByAccount
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(464, 376);
            this.Controls.Add(this.btnIntro);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblWarning);
            this.Controls.Add(this.lblTest);
            this.Controls.Add(this.btnLogin);
            this.Controls.Add(this.lblUserId);
            this.Controls.Add(this.txbUserId);
            this.Controls.Add(this.lblByCard);
            this.Controls.Add(this.lblPwd);
            this.Controls.Add(this.txbPwd);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "LoginByAccount";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "\"Hello World - Taiwan!\"";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txbPwd;
        private System.Windows.Forms.Label lblPwd;
        private System.Windows.Forms.Label lblByCard;
        private System.Windows.Forms.Label lblUserId;
        private System.Windows.Forms.TextBox txbUserId;
        private System.Windows.Forms.Button btnLogin;
        private System.Windows.Forms.Label lblTest;
        private System.Windows.Forms.Label lblWarning;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnIntro;
    }
}