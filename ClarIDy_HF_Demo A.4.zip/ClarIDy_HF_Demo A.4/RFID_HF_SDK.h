// File: RFID_HF_SDK.h
//
// Copyright (c) 2008 ClarIDy Solutions, Inc.
// All rights reserved.
// 
// Author: Horng-Ji Chen
// 
// Descriptions: RFID_HF_SDK provides the API (Application Program Interface)
//				 functions of ClarIDy HF RFID/NFC Reader controls. The supported
//				 protocols include:
//				 ISO-15693,
//				 ISO-14443A and ISO-1443B,
//				 FeLiCa, and
//				 ISO-18904.
//
// RFID_HF_SDK.dll
// Revision: A.3
//
// History:
// 2008-07-21: Rev. A.1 by Horng-Ji Chen
// Created the fundamental API functions for the HF RFID/NFC SDK.
//
// 2008-08-08: Rev. A.2 by Horng-Ji Chen
// Generated RFID_HF_SDK.dll to have well defined API interfaces.
// Renamed some of the function names and most of the parameters to have better
// naming rules.
//
// 2008-11-03: Rev. A.3 by Horng-Ji Chen
// Added RFID 15693 ReadMultiUID function and Secure function.

// The following ifdef block is the standard way of creating macros which make exporting 
// from a DLL simpler. All files within this DLL are compiled with the RFID_HF_SDK_EXPORTS
// symbol defined on the command line. this symbol should not be defined on any project
// that uses this DLL. This way any other project whose source files include this file see 
// RFID_HF_SDK_API functions as being imported from a DLL, whereas this DLL sees symbols
// defined with this macro as being exported.

#ifdef RFID_HF_SDK_EXPORTS
#define RFID_HF_SDK_API __declspec(dllexport)
#else
#define RFID_HF_SDK_API __declspec(dllimport)
#endif

typedef unsigned int UInt32;

// This class is exported from the RFID_HF_SDK.dll
class RFID_HF_SDK_API CRFID_HF_SDK {
public:
	CRFID_HF_SDK(void);
	// TODO: add your methods here.
};

// extern RFID_HF_SDK_API int nRFID_HF_SDK;

// RFID_HF_SDK_API int fnRFID_HF_SDK(void);


// HF Reader Connection Control Function
RFID_HF_SDK_API int RFID_HF_Connect(int iType, int iPort, int iBaudrate);
RFID_HF_SDK_API int RFID_HF_Disconnect(int iHandle);



// Generic Functions
RFID_HF_SDK_API int RFID_GetVersion(int iHandle, unsigned char* ucpData,int Mode);
RFID_HF_SDK_API int RFID_GetReaderModel(int iHandle);
RFID_HF_SDK_API int RFID_ReadGValue(int iHandle, unsigned short usIndex, unsigned char* ucpData);
RFID_HF_SDK_API int RFID_WriteGValue(int iHandle, unsigned short usIndex, unsigned char ucDataLength, unsigned char* ucpData);
RFID_HF_SDK_API int RFID_ReadXData(int iHandle, unsigned short usAddress, unsigned char ucLength, unsigned char *ucpData);
RFID_HF_SDK_API int RFID_WriteXData(int iHandle, unsigned short usAddress, unsigned char ucLength, unsigned char *ucpData);
RFID_HF_SDK_API char * RFID_ErrorMessage(int iCode);
RFID_HF_SDK_API void RFID_HF_SDK_Ver(unsigned char* ucpData);

// ISO 15693 Control Functions
RFID_HF_SDK_API int RFID_15693_ReadUID(int iHandle, int iAFIFlag, unsigned char ucAFI, unsigned char* ucpUID);
RFID_HF_SDK_API int RFID_15693_ReadMultiUID(int iHandle, int iAFIFlag, unsigned char ucAFI, unsigned char * ucpUID);
RFID_HF_SDK_API int RFID_15693_ReadOneBlock(int iHandle, unsigned char* ucpUID, int iBytePerBlock, int iBlockNum, unsigned char* ucpReport, unsigned char *ucpBlockStatus);
// RFID_HF_SDK_API int RFID_15693_ReadOneBlockSel(int iHandle, int iBytePerBlock, int iBlockNum, unsigned char* ucpReport, unsigned char *ucpBlockStatus);
RFID_HF_SDK_API int RFID_15693_WriteOneBlock(int iHandle, unsigned char* ucpUID, int iBytePerBlock, int iBlockNum, unsigned char* ucpReport, unsigned char ucOption);
RFID_HF_SDK_API int RFID_15693_StayQuiet(int iHandle, unsigned char* ucpUID);
RFID_HF_SDK_API int RFID_15693_ResetToReady(int iHandle, unsigned char* ucpUID);
RFID_HF_SDK_API int RFID_15693_Select(int iHandle, unsigned char* ucpUID);
RFID_HF_SDK_API int RFID_15693_GetSysInfo(int iHandle, unsigned char* ucpUID, int *ipBytePerBlock, int *ipBlockSize, unsigned char *ucpAFI, unsigned char *ucpDSFID, unsigned char *ucpFlag);
RFID_HF_SDK_API int RFID_15693_WriteAFI(int iHandle, unsigned char* ucpUID, unsigned char ucAFI, unsigned char ucOption);
RFID_HF_SDK_API int RFID_15693_WriteDSF(int iHandle, unsigned char* ucpUID, unsigned char ucDSFID, unsigned char ucOption);
RFID_HF_SDK_API int RFID_15693_LockAFI(int iHandle, unsigned char* ucpUID, unsigned char ucOption);
RFID_HF_SDK_API int RFID_15693_LockDSF(int iHandle, unsigned char* ucpUID, unsigned char ucOption);
RFID_HF_SDK_API int RFID_15693_LockBlock(int iHandle, unsigned char* ucpUID, int iBlockNum, unsigned char ucOption);
RFID_HF_SDK_API int RFID_15693_BlockLockInfo(int iHandle, unsigned char* ucpUID, int iStartBlock, int iBlockNum, unsigned char* ucpBlockLockInfo);
RFID_HF_SDK_API int RFID_15693_ReadMultiBlock(int iHandle, unsigned char* ucpUID, int iStartBlock, int iBlockNum, unsigned char* ucpBlockData, unsigned char ucOption);
RFID_HF_SDK_API int RFID_15693_ReadEAS(int iHandle, unsigned char* ucpUID, unsigned char *ucpEAS);
RFID_HF_SDK_API int RFID_15693_WriteEAS(int iHandle, unsigned char* ucpUID, unsigned char ucEAS);
RFID_HF_SDK_API int RFID_15693_LockEAS(int iHandle, unsigned char* ucpUID);
RFID_HF_SDK_API int RFID_15693_SecureReadBlock(int iHandle, unsigned char* ucpUID, int iBytePerBlock, int iBlockNum, unsigned char* ucpPWD, int iPWDLength, unsigned char* ucpReport, unsigned char *ucpBlockStatus);
RFID_HF_SDK_API int RFID_15693_SecureWriteBlock(int iHandle, unsigned char* ucpUID, int iBytePerBlock, int iBlockNum, unsigned char* ucpPWD, int iPWDLength, unsigned char* ucpData);
RFID_HF_SDK_API int RFID_15693_ReadOID(int iHandle, unsigned char* ucpUID, unsigned char* ucpReport);
RFID_HF_SDK_API int RFID_15693_WritePWD(int iHandle, unsigned char* ucpUID, int iBytePerBlock, int iPWDLength, unsigned char* ucpData);
RFID_HF_SDK_API int RFID_15693_LockPWD(int iHandle, unsigned char* ucpUID);
RFID_HF_SDK_API int RFID_15693_ReadKey(int iHandle, unsigned char* ucpUID, unsigned char* ucpReport);
RFID_HF_SDK_API int RFID_15693_WriteKey(int iHandle, unsigned char* ucpUID, int iBytePerBlock, unsigned char* ucpData);
RFID_HF_SDK_API int RFID_15693_LockKey(int iHandle, unsigned char* ucpUID);
RFID_HF_SDK_API int RFID_15693_FastReadBlock(int iHandle, unsigned char* ucpUID, int iBytePerBlock, int iBlockNum, unsigned char* ucpReport, unsigned char *ucpBlockStatus);
RFID_HF_SDK_API int RFID_15693_FastReadUID(int iHandle, int iAFIFlag, unsigned char ucAFI, unsigned char* ucpUID);
RFID_HF_SDK_API int RFID_15693_FastWriteOneBlock(int iHandle, unsigned char* ucpUID, int iBytePerBlock, int iBlockNum, unsigned char* ucpReport, unsigned char ucOption);


// ISO 14443 Control Functions
RFID_HF_SDK_API int RFID_14443A_ReadUID(int iHandle, unsigned char *ucpTagNum, unsigned char* UIDlength, unsigned char* ucpUID);
RFID_HF_SDK_API int RFID_14443B_ReadUID(int iHandle, unsigned char *ucpTagNum, unsigned char* ucpUID);
RFID_HF_SDK_API int RFID_14443B_ReadBlock(int iHandle, unsigned char* ucpUID, unsigned char ucAddress, unsigned char* ucpData);
RFID_HF_SDK_API int RFID_14443B_WriteBlock(int iHandle, unsigned char* ucpUID, unsigned char ucAddress, unsigned char* ucpData);
RFID_HF_SDK_API int RFID_14443B_Attribute(int iHandle, unsigned char ucCID, unsigned char* ucpPUPI, unsigned char* ucpData);
RFID_HF_SDK_API int RFID_14443B_Completion(int iHandle, unsigned char *ucpUID);


// Atmel Tag Control Functions
RFID_HF_SDK_API int RFID_14443B_ReadUID_Std(int iHandle, unsigned char *ucpTagNum, unsigned char* ucpUID, unsigned char* ucpCID, unsigned char ucOption);
RFID_HF_SDK_API int RFID_AT88RF020_Read(int iHandle, unsigned char ucCID, unsigned char ucAddress, unsigned char* ucpData);
RFID_HF_SDK_API int RFID_AT88RF020_Write(int iHandle, unsigned char ucCID, unsigned char ucAddress, unsigned char* ucpWriteData, unsigned char* ucpData);
RFID_HF_SDK_API int RFID_AT88RF020_CheckPWD(int iHandle, unsigned char ucCID, unsigned char* ucpPWD, unsigned char* ucpData);
RFID_HF_SDK_API int RFID_AT88RF020_Deselect(int iHandle, unsigned char ucCID, unsigned char* ucpData);
RFID_HF_SDK_API int RFID_AT88RF020_Lock(int iHandle, unsigned char ucCID, unsigned char* ucpLockData, unsigned char* ucpData);
RFID_HF_SDK_API int RFID_AT88RF020_Count(int iHandle, unsigned char ucCID, unsigned char* ucpCountData, unsigned char* ucpData);


// Mifare UltraLight Control Functions
RFID_HF_SDK_API int RFID_UltraLight_ReadBlocks(int iHandle, unsigned char ucAddress, unsigned char *ucpData);
RFID_HF_SDK_API int RFID_UltraLight_WriteBlock(int iHandle, unsigned char ucAddress, unsigned char *ucpWriteData, unsigned char *ucpData);


// TOPAZ Control Functions
RFID_HF_SDK_API int RFID_TOPAZ_WakeUp(int iHandle, unsigned char *ucpData);
RFID_HF_SDK_API int RFID_TOPAZ_ReadUID(int iHandle, unsigned char *ucpData);
RFID_HF_SDK_API int RFID_TOPAZ_ReadByte(int iHandle, unsigned char ucAddress, unsigned char *ucpUID, unsigned char *ucpData);
RFID_HF_SDK_API int RFID_TOPAZ_WriteByte(int iHandle, unsigned char ucAddress, unsigned char ucData, unsigned char *ucpUID, unsigned char *ucpData);


// FeliCa Control Functions
RFID_HF_SDK_API int RFID_FeliCa_ReadUID(int iHandle, unsigned char* ucpUID); //FeliCa Tag


// File Transfer Functions
typedef void ( *m3xTxCB )( unsigned long ulByteCount, unsigned long ulFileSize );
typedef void ( *m3xRxCB )( unsigned long ulByteCount, unsigned long ulFileSize, unsigned char *ucpFilename );

RFID_HF_SDK_API int RFID_M3XSendFile(int iHandle, unsigned char* ucpFilename, m3xTxCB pCB);
RFID_HF_SDK_API int RFID_M3XReceiveFile(int iHandle, unsigned char* ucpFilePath, m3xRxCB pCB);

//Secure
RFID_HF_SDK_API void RFID_MD5Hash(unsigned char *input, int inputlen, unsigned char *output);
RFID_HF_SDK_API int RFID_RSAGenKeyPair(int size, char *keyfilename);
RFID_HF_SDK_API int RFID_RSASetKey(int mode, int size, char *keyfilename);
RFID_HF_SDK_API int RFID_RSAEncrypt(int mode, int inputlen, unsigned char *input, unsigned char *output);
RFID_HF_SDK_API int RFID_RSADecrypt(int mode, int *outputlen, unsigned char *input, unsigned char *output);
RFID_HF_SDK_API void RFID_AESSetKey(int mode, unsigned char *key, int keysize);
RFID_HF_SDK_API void RFID_AESCrypt(int mode, unsigned char *input, unsigned char *output);