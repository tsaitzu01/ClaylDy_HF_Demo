﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using MySql.Data.MySqlClient;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using RFID_HF_SDK;

using System.Runtime.InteropServices;
using System.Threading;
using System.Collections;
using ClarIDy_HF_DEMO;
using System.Configuration;
using System.Net.Mail;
using System.Text.RegularExpressions;

namespace ClarIDy_HF_Demo
{
    public partial class TopPage : Form
    {
        string sUID = "";
        string gender = "";
        //string connectionString = "server=120.126.18.177; database=player; uid=root; pwd=root";
        string connectionString = "server=192.168.231.98; database=player; uid=root; pwd=root";
        int record;
        Boolean CheckPwd = false;
        MySqlConnection connection;
        [DllImport("kernel32.dll")]
        extern static short QueryPerformanceCounter(ref long x);
        [DllImport("kernel32.dll")]
        extern static short QueryPerformanceFrequency(ref long x);

        #region Win32
        [DllImport("user32.dll")]
        static extern void MessageBeep(uint uType);

        const uint MB_OK = 0x00000000;

        const uint MB_ICONHAND = 0x00000010;
        const uint MB_ICONQUESTION = 0x00000020;
        const uint MB_ICONEXCLAMATION = 0x00000030;
        const uint MB_ICONASTERISK = 0x00000040;

        const byte IO_LED = 0x04;
        const byte IO_BEEP = 0x05;
        #endregion

        public DataSet m_datasetUID = null;
        public DataSet m_datasetBlockData = null;
        int m_iHandle = -1;

        #region Form Controls
        public TopPage()
        {
            InitializeComponent();
            txbPwd.PasswordChar = '\u25CF';
            txbCheckPwd.PasswordChar = '\u25CF';
            //string connString = "server=120.126.18.177;port=3306;user id=root;password=root;database=player;charset=utf8;";
            //MySqlConnection conn = new MySqlConnection(connString);
            //MySqlDataAdapter adapter = new MySqlDataAdapter();
            //conn.Open();
            //string cn = "server=120.126.18.177;user id=root;Password=root;persist security info=True;database=mysql";
        }
        private void TopPage_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (m_iHandle >= 0) {
                RFID_HF_SDK.RFID_HF_API.RFID_HF_Disconnect(m_iHandle);
                m_iHandle = -1;
            }
            System.Environment.Exit(0);
        }
        private void TopPage_Load(object sender, EventArgs e)
        {

            m_datasetUID = new DataSet();
            m_datasetUID.Tables.Add("UserDB");
        }
        #endregion

        #region Connect RFID
        private void txbRfid_MouseClick(object sender, MouseEventArgs e)
        {
            int iType = 4;
            int iPort = 0;
            int iBaudRate = 115200;

            int Res = RFID_HF_API.RFID_HF_Disconnect(m_iHandle);
            m_iHandle = -1;

            m_iHandle = RFID_HF_API.RFID_HF_Connect(iType, iPort, iBaudRate); //for USB

            if (m_iHandle >= 0)
            {
                int iModel = RFID_HF_API.RFID_GetReaderModel(m_iHandle);
                if (iModel >= 0)
                    lblTest.Text = "讀卡機已連接，請嗶卡！";
                else
                    lblTest.Text = "請確認讀卡機已連接";
            }
            else
                m_iHandle = -1;
            timer1.Enabled = true;
        }
        #endregion

        #region Timer Controls
        private void timer1_Tick(object sender, EventArgs e)
        {
            string UID = Get_UID();
            txbRfid.Text = UID;
        }
        #endregion

        private void btnSign_Click(object sender, EventArgs e)
        {
            //驗證輸入資料是否正確
            checkInfo();

            //傳進資料庫 
            if (record == 0 && CheckPwd)
            {
                using (connection = new MySqlConnection(connectionString))
                {
                    try
                    {
                        string insertData = "insert into player_data(card_num, name, email, password, gender) values (@card_num, @name, @email, @password, @gender)";
                        MySqlCommand command = new MySqlCommand(insertData, connection);
                        command.Parameters.AddWithValue("@card_num", txbRfid.Text);
                        command.Parameters.AddWithValue("@name", txbNickname.Text);
                        command.Parameters.AddWithValue("@email", txbUserID.Text);
                        command.Parameters.AddWithValue("@password", txbPwd.Text);
                        command.Parameters.AddWithValue("@gender", gender);
                        connection.Open();
                        command.ExecuteNonQuery();
                        connection.Close();
                        MessageBox.Show("註冊成功！","\"Hello World - Taiwan!\"");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Failed to connect to database due to" + ex.ToString());
                        MessageBox.Show("Failed to insert data due to" + ex.ToString());
                    }
                }
                MyPage frm = new MyPage(txbUserID.Text);
                frm.Show();
                timer1.Enabled = false;
                int Res = RFID_HF_API.RFID_HF_Disconnect(m_iHandle);
                m_iHandle = -1;
                this.Hide();
            } //EndIf Sign up
        }

        private void checkInfo()
        {
            record = 0;
            if (txbNickname.Text == string.Empty)
            {
                lblWarning1.Text = "此處不可為空值";
                record = 1;
            }
            if (txbUserID.Text == string.Empty)
            {
                lblWarning2.Text = "此處不可為空值";
                record = 1;
            }
            if (txbPwd.Text == string.Empty)
            {
                lblWarning3.Text = "此處不可為空值";
                record = 1;

            }
            if (gender == string.Empty)
            {
                lblWarning5.Text = "請選擇頭像";
                record = 1;
            }
            if (txbRfid.Text == string.Empty)
                lblWarning4.Text = null;
        }

        private string Get_UID()
        {
            uint TotalCnt = 0;
            byte TagNo = 0;
            int i, j, Res;
            byte[] uid = new byte[160];
            byte[] UIDLen = new byte[8];
            byte[] cid = new byte[8];

            Res = RFID_HF_API.RFID_14443A_ReadUID(m_iHandle, ref TagNo, UIDLen, uid);
            if (Res == 0)
            {
                TotalCnt += TagNo;
                for (i = 0; i < TagNo; i++)
                {
                    sUID = "";
                    if (UIDLen[i] > 0)
                    {
                        for (j = 0; j < UIDLen[i]; j++)
                        {
                            sUID += uid[i * 10 + (UIDLen[i] - 1) - j].ToString("X").PadLeft(2, '0');
                        }
                    }
                }
            }
            return sUID;
        }

        private void pictBlue_Click(object sender, EventArgs e)
        {
            pictUser.Image = pictBlue.Image;
            gender = "0";
        }

        private void pictPink_Click(object sender, EventArgs e)
        {
            pictUser.Image = pictPink.Image;
            gender = "1";
        }

        private void btnIntro_Click(object sender, EventArgs e)
        {
            if (m_iHandle >= 0)
            {
                connection = new MySqlConnection(connectionString);
                connection.Close();
            }
            IntroPage frm = new IntroPage();
            frm.Show();
            //this.Hide();
        }

        private void txbUserID_TextChanged(object sender, EventArgs e)
        {
            bool isEmail = Regex.IsMatch(txbUserID.Text, @"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z", RegexOptions.IgnoreCase);
            if (!isEmail)
                lblWarning2.Text = "電子郵件格式不符合";
            else
                lblWarning2.Text = "";
            MySqlConnection connection = new MySqlConnection(connectionString);
            string selectPassword = "select password from player_data where email = @email";
            MySqlCommand command = new MySqlCommand(selectPassword, connection);
            command.Parameters.AddWithValue("@email", txbUserID.Text);
            connection.Open();
            object password = command.ExecuteScalar();
            if (password != null)
            {
                lblWarning2.Text = "此電子郵件已註冊";
                record = 1;
            }
            connection.Close();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            if (m_iHandle >= 0)
            {
                connection = new MySqlConnection(connectionString);
                connection.Close();
            }

            LoginByCard frm = new LoginByCard();
            frm.Show();
            int Res = RFID_HF_API.RFID_HF_Disconnect(m_iHandle);
            m_iHandle = -1;
            this.Hide();
        }

        private void txbCheckPwd_TextChanged(object sender, EventArgs e)
        {
            if (txbPwd.Text == txbCheckPwd.Text)
            {
                lblCheckPwd.Text = "密碼一致";
                CheckPwd = true;
            }
            else
                lblCheckPwd.Text = "密碼不符合，請重新輸入";
        }
    }
}
