﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using MySql.Data.MySqlClient;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using RFID_HF_SDK;

using System.Runtime.InteropServices;
using ClarIDy_HF_Demo;
using System.Text.RegularExpressions;

namespace ClarIDy_HF_DEMO
{
    public partial class LoginByCard : Form
    {
        string sUID = "";
        MySqlConnection connection;
        [DllImport("kernel32.dll")]
        extern static short QueryPerformanceCounter(ref long x);
        [DllImport("kernel32.dll")]
        extern static short QueryPerformanceFrequency(ref long x);

        #region Win32
        [DllImport("user32.dll")]
        static extern void MessageBeep(uint uType);

        const uint MB_OK = 0x00000000;

        const uint MB_ICONHAND = 0x00000010;
        const uint MB_ICONQUESTION = 0x00000020;
        const uint MB_ICONEXCLAMATION = 0x00000030;
        const uint MB_ICONASTERISK = 0x00000040;

        const byte IO_LED = 0x04;
        const byte IO_BEEP = 0x05;
        #endregion

        public DataSet m_datasetUID = null;
        public DataSet m_datasetBlockData = null;
        int m_iHandle = -1;

        public LoginByCard()
        {
            InitializeComponent();
        }
        private void LoginByCard_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (m_iHandle >= 0)
            {
                RFID_HF_SDK.RFID_HF_API.RFID_HF_Disconnect(m_iHandle);
                m_iHandle = -1;
            }
        }

        #region Connect RFID
        private void txbRfid_MouseClick(object sender, EventArgs e)
        {
            int iType = 4;
            int iPort = 0;
            int iBaudRate = 115200;

            int Res = RFID_HF_API.RFID_HF_Disconnect(m_iHandle);
            m_iHandle = -1;

            m_iHandle = RFID_HF_API.RFID_HF_Connect(iType, iPort, iBaudRate); //for USB

            if (m_iHandle >= 0)
            {
                int iModel = RFID_HF_API.RFID_GetReaderModel(m_iHandle);
                if (iModel >= 0)
                    lblTest.Text = "讀卡機已連接，請嗶卡！";
                else
                    lblTest.Text = "請確認讀卡機已連接";
            }
            else
                m_iHandle = -1;
            timer1.Enabled = true;
        }
        #endregion

        #region Timer Controls
        private void timer1_Tick(object sender, EventArgs e)
        {
            string UID = Get_UID_login();
            txbRfid.Text = UID;
        }
        #endregion

        private string Get_UID_login()
        {
            uint TotalCnt = 0;
            byte TagNo = 0;
            int i, j, Res;
            byte[] uid = new byte[160];
            byte[] UIDLen = new byte[8];
            byte[] cid = new byte[8];

            Res = RFID_HF_API.RFID_14443A_ReadUID(m_iHandle, ref TagNo, UIDLen, uid);
            if (Res == 0)
            {
                TotalCnt += TagNo;
                for (i = 0; i < TagNo; i++)
                {
                    sUID = "";
                    if (UIDLen[i] > 0)
                    {
                        for (j = 0; j < UIDLen[i]; j++)
                        {
                            sUID += uid[i * 10 + (UIDLen[i] - 1) - j].ToString("X").PadLeft(2, '0');
                        }
                    }
                }
            }
            return sUID;
        }

        private void txbRfid_TextChanged(object sender, EventArgs e)
        {
            string connectionString = "server=120.126.18.177; database=player; uid=root; pwd=root";
            //string connectionString = "server=192.168.231.98; database=player; uid=root; pwd=root";
            connection = new MySqlConnection(connectionString);
            string selectPassword = "select password from player_data where card_num = @card_num";
            MySqlCommand command = new MySqlCommand(selectPassword, connection);
            command.Parameters.AddWithValue("@card_num", txbRfid.Text);
            connection.Open();
            object password = command.ExecuteScalar();
            if (password != null)
            {
                int Res = RFID_HF_API.RFID_HF_Disconnect(m_iHandle);
                m_iHandle = -1;
                MyPage frm = new MyPage(txbRfid.Text);
                frm.Show();
                this.Hide();
            }
            else
                lblTest.Text = "此學生證尚未註冊";
            connection.Close();
        }

        private void lblByCard_Click(object sender, EventArgs e)
        {
            LoginByAccount frm = new LoginByAccount();
            frm.Show();
            int Res = RFID_HF_API.RFID_HF_Disconnect(m_iHandle);
            m_iHandle = -1;
            this.Hide();
        }

        private void LoginByCard_FormClosing_1(object sender, FormClosingEventArgs e)
        {
            if (m_iHandle >= 0)
            {
                RFID_HF_SDK.RFID_HF_API.RFID_HF_Disconnect(m_iHandle);
                m_iHandle = -1;
            };
        }

        private void label2_Click(object sender, EventArgs e)
        {
            TopPage frm = new TopPage();
            frm.Show();
            int Res = RFID_HF_API.RFID_HF_Disconnect(m_iHandle);
            m_iHandle = -1;
            this.Hide();
        }

        private void btnIntro_Click(object sender, EventArgs e)
        {
            IntroPage frm = new IntroPage();
            frm.Show();
            //this.Hide();
        }
    }
}
